# DÉPLOIEMENT BADAOUR — 3 étapes

## Étape 1 — GitHub
1. Va sur github.com → ton repo BADAOUR
2. Clique "Add file" → "Upload files"  
3. Glisse TOUS les fichiers de ce dossier (sauf node_modules)
4. "Commit changes"

## Étape 2 — Vercel (si encore rouge)
1. Va sur vercel.com → projet BADAOUR
2. Settings → General → Framework Preset → choisis "Vite"
3. Settings → General → Output Directory → tape "dist"
4. Clique "Save"
5. Deployments → "Redeploy"

## Étape 3 — Variables d'environnement
1. vercel.com → Settings → Environment Variables
2. BREVO_API_KEY = ta clé xkeysib-...
