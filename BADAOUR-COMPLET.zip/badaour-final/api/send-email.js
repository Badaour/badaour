const BREVO_API_URL = "https://api.brevo.com/v3/smtp/email";

function getTemplate(type, data) {
  const G = "#C9A84C";
  const DARK = "#1A1714";

  const base = (content) => `<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>BADAOUR</title>
</head>
<body style="margin:0;padding:0;background:#F5F0E8;font-family:Georgia,serif;">
<table width="100%" cellpadding="0" cellspacing="0">
<tr><td align="center" style="padding:32px 16px;">
<table width="560" cellpadding="0" cellspacing="0" style="background:#FDFCF9;border-radius:8px;overflow:hidden;">
<tr><td style="background:${DARK};padding:24px 32px;text-align:center;">
<div style="font-family:Georgia,serif;font-size:28px;font-weight:900;color:${G};letter-spacing:4px;">BADAOUR</div>
<div style="font-size:10px;color:rgba(201,168,76,0.7);letter-spacing:3px;margin-top:4px;">L'AFRIQUE A VOTRE PORTE</div>
</td></tr>
<tr><td style="padding:32px;">${content}</td></tr>
<tr><td style="background:${DARK};padding:20px 32px;text-align:center;">
<p style="margin:0 0 6px;font-size:12px;color:#8A7E6E;">438-988-6682 - service@badaour.com</p>
<p style="margin:0;font-size:11px;color:#5A4E42;">Montreal, Quebec - Canada</p>
</td></tr>
</table>
</td></tr>
</table>
</body>
</html>`;

  if (type === "bienvenue") {
    return {
      subject: "Bienvenue dans la famille BADAOUR !",
      html: base(`
        <h2 style="color:${DARK};font-family:Georgia,serif;margin:0 0 16px;">Bienvenue ${data.client || ""} !</h2>
        <p style="color:#4A3F35;line-height:1.7;margin:0 0 16px;font-family:Arial,sans-serif;font-size:13px;">Votre compte BADAOUR a ete cree avec succes. Nous sommes ravis de vous accueillir dans notre communaute.</p>
        <div style="text-align:center;margin:24px 0;">
          <a href="https://badaour.com" style="background:${G};color:${DARK};padding:14px 32px;border-radius:4px;text-decoration:none;font-weight:700;font-family:Arial,sans-serif;font-size:13px;">DECOUVRIR LA BOUTIQUE</a>
        </div>
      `)
    };
  }

  if (type === "commande") {
    const items = (data.items || []).map(i =>
      `<tr>
        <td style="padding:8px 0;border-bottom:1px solid #E8DDD0;font-family:Arial,sans-serif;font-size:13px;color:#4A3F35;">${i.name}</td>
        <td style="padding:8px 0;border-bottom:1px solid #E8DDD0;text-align:center;font-family:Arial,sans-serif;font-size:13px;">x${i.qty||1}</td>
        <td style="padding:8px 0;border-bottom:1px solid #E8DDD0;text-align:right;font-family:Arial,sans-serif;font-size:13px;color:${G};font-weight:700;">${i.price}$</td>
      </tr>`
    ).join("");
    return {
      subject: `Confirmation commande BADAOUR #${data.orderId || ""}`,
      html: base(`
        <h2 style="color:${DARK};font-family:Georgia,serif;margin:0 0 16px;">Commande confirmee !</h2>
        <p style="color:#4A3F35;font-family:Arial,sans-serif;font-size:13px;">Bonjour ${data.client || ""}, votre commande <strong>#${data.orderId || ""}</strong> a ete recue.</p>
        <table width="100%" cellpadding="0" cellspacing="0" style="margin:16px 0;">
          <tr>
            <th style="text-align:left;padding:8px 0;border-bottom:2px solid ${G};font-family:Arial,sans-serif;font-size:11px;color:#8A7E6E;">PRODUIT</th>
            <th style="text-align:center;padding:8px 0;border-bottom:2px solid ${G};font-family:Arial,sans-serif;font-size:11px;color:#8A7E6E;">QTE</th>
            <th style="text-align:right;padding:8px 0;border-bottom:2px solid ${G};font-family:Arial,sans-serif;font-size:11px;color:#8A7E6E;">PRIX</th>
          </tr>
          ${items}
          <tr>
            <td colspan="2" style="padding:12px 0 0;font-family:Arial,sans-serif;font-weight:700;color:${DARK};">Total</td>
            <td style="padding:12px 0 0;text-align:right;font-family:Arial,sans-serif;font-size:16px;font-weight:700;color:${G};">${data.total || "0"}$</td>
          </tr>
        </table>
        <p style="color:#4A3F35;font-family:Arial,sans-serif;font-size:13px;">Questions : <a href="mailto:service@badaour.com" style="color:${G};">service@badaour.com</a></p>
      `)
    };
  }

  if (type === "suivi") {
    return {
      subject: `Mise a jour commande BADAOUR #${data.orderId || ""}`,
      html: base(`
        <h2 style="color:${DARK};font-family:Georgia,serif;margin:0 0 16px;">Mise a jour de votre commande</h2>
        <p style="color:#4A3F35;font-family:Arial,sans-serif;font-size:13px;">Bonjour ${data.client || ""}, votre commande <strong>#${data.orderId || ""}</strong> a ete mise a jour.</p>
        <div style="background:#F5F0E8;border-left:4px solid ${G};padding:16px 20px;margin:20px 0;">
          <p style="margin:0;font-family:Arial,sans-serif;font-size:14px;font-weight:700;color:${DARK};">Statut : ${data.newStatus || ""}</p>
          ${data.message ? `<p style="margin:8px 0 0;font-family:Arial,sans-serif;font-size:13px;color:#4A3F35;">${data.message}</p>` : ""}
        </div>
      `)
    };
  }

  if (type === "artisan") {
    return {
      subject: "Demande partenariat BADAOUR recue",
      html: base(`
        <h2 style="color:${DARK};font-family:Georgia,serif;margin:0 0 16px;">Demande recue !</h2>
        <p style="color:#4A3F35;font-family:Arial,sans-serif;font-size:13px;">Bonjour ${data.name || ""}, nous avons recu votre demande de partenariat en tant que <strong>${data.metier || ""}</strong> du <strong>${data.pays || ""}</strong>.</p>
        <p style="color:#4A3F35;font-family:Arial,sans-serif;font-size:13px;">Notre equipe vous contactera tres bientot.</p>
      `)
    };
  }

  return {
    subject: data.subject || "Message de BADAOUR",
    html: base(`<p style="color:#4A3F35;font-family:Arial,sans-serif;font-size:13px;">${data.message || ""}</p>`)
  };
}

module.exports = async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Methode non autorisee" });

  const BREVO_KEY = process.env.BREVO_API_KEY;
  if (!BREVO_KEY) return res.status(500).json({ error: "Cle API Brevo manquante" });

  const { type, to, toName, data = {} } = req.body || {};
  if (!type || !to) return res.status(400).json({ error: "Parametres manquants" });

  try {
    const template = getTemplate(type, data);
    const payload = {
      sender: { name: "BADAOUR", email: "service@badaour.com" },
      to: [{ email: to, name: toName || to }],
      replyTo: { email: "service@badaour.com", name: "BADAOUR" },
      subject: template.subject,
      htmlContent: template.html,
    };

    if (type === "commande") {
      payload.bcc = [{ email: "service@badaour.com", name: "BADAOUR Admin" }];
    }

    const response = await fetch(BREVO_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "api-key": BREVO_KEY,
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const err = await response.json();
      return res.status(500).json({ error: "Erreur Brevo", details: err });
    }

    const result = await response.json();
    return res.status(200).json({ success: true, messageId: result.messageId });

  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};
