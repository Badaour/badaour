import { useState, useEffect, useRef } from "react";
import { sendEmail, sendTrackingUpdate, sendCustomEmail } from "./communication.js";

/* ══ CSS ══════════════════════════════════════════════════════════════════ */
const CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,900;1,700;1,900&family=DM+Sans:wght@300;400;500;600;700&display=swap');
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
  html,body{font-family:'DM Sans',sans-serif}
  ::-webkit-scrollbar{width:4px;height:4px}
  ::-webkit-scrollbar-thumb{background:#C9A84C;border-radius:4px}
  input,textarea,select,button{font-family:'DM Sans',sans-serif}
  input[type=file]{display:none!important}
  @keyframes fadeUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
  @keyframes toast{from{opacity:0;transform:translate(-50%,12px)}to{opacity:1;transform:translate(-50%,0)}}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes floatA{0%,100%{transform:translateY(0)}50%{transform:translateY(-12px)}}
  @keyframes twinkle{0%,100%{opacity:.9}50%{opacity:.2}}
  .page{animation:fadeUp .38s cubic-bezier(.22,1,.36,1) both}
  .row:hover{background:#F5F0E8!important}
  .snav{transition:all .18s;border-left:3px solid transparent}
  .snav:hover{background:rgba(201,168,76,.12)!important;color:#C9A84C!important}
  .snav.on{background:rgba(201,168,76,.18)!important;color:#C9A84C!important;border-left-color:#C9A84C!important;font-weight:600!important}
  .ibtn{transition:all .18s;cursor:pointer}
  .ibtn:hover{transform:translateY(-1px);opacity:.9}
  .ibtn:active{transform:scale(.96)}
  .uzone{border:2px dashed rgba(201,168,76,.35);border-radius:10px;cursor:pointer;transition:all .2s;display:flex;flex-direction:column;align-items:center;justify-content:center}
  .uzone:hover{border-color:#C9A84C;background:rgba(201,168,76,.05)}
  .spin{animation:spin .7s linear infinite}
  .card{transition:box-shadow .2s,transform .2s}
  .card:hover{box-shadow:0 8px 28px rgba(0,0,0,.1)!important;transform:translateY(-2px)}
  .kpi-card{transition:box-shadow .2s}
  .kpi-card:hover{box-shadow:0 6px 24px rgba(0,0,0,.1)!important}
`;
function injectCSS(){
  if(document.getElementById("adm-css"))return;
  const s=document.createElement("style");s.id="adm-css";s.textContent=CSS;document.head.appendChild(s);
}

const G="#C9A84C",DARK="#1A1714",RED="#8B1A00",GREEN="#1E6E3D",BG="#FDFCF9",BG2="#F5F0E8",MUT="#8A7E6E",BDR="#E8E2D8";
const S="'Playfair Display',serif",SAN="'DM Sans',sans-serif";
const PHONE="438-988-6682",EMAIL="service@badaour.com";
const CATS=["homme","femme","enfant","art","divers"];
const TAGS=["Bestseller","Nouveau","Artisanal","Populaire","Unique","Bio","Premium"];
const STATUS_FLOW=["confirmed","preparation","shipped","transit","customs","delivery","delivered"];
const MAX_PHOTOS=5;

/* ══ STORAGE ══════════════════════════════════════════════════════════════ */
const STORAGE_KEY=id=>`bdr-photos-${id}`;
async function savePhotos(pid,photos){
  try{await window.storage.set(STORAGE_KEY(pid),JSON.stringify(photos),true);}catch(e){}
}
async function loadAllPhotos(products){
  const r={};
  for(const p of products){
    try{const x=await window.storage.get(STORAGE_KEY(p.id),true);if(x&&x.value)r[p.id]=JSON.parse(x.value);}catch(e){}
  }
  return r;
}

/* ══ DATA ═════════════════════════════════════════════════════════════════ */
const INIT_P=[
  {id:1, name:"Grand Boubou Brodé",      cat:"homme", artisan:"Moussa Diallo",    country:"Sénégal",     price:189,tag:"Bestseller",stock:12,sold:47,desc:"Broderie main sur bazin riche.",emoji:"◈"},
  {id:2, name:"Dashiki Festif",           cat:"homme", artisan:"Koffi Asante",     country:"Ghana",       price:78, tag:"Nouveau",   stock:25,sold:33,desc:"Coton léger brodé, col en V.",  emoji:"◈"},
  {id:3, name:"Agbada Cérémonie",         cat:"homme", artisan:"Adebayo Okafor",   country:"Nigeria",     price:245,tag:"Premium",   stock:5, sold:18,desc:"Ensemble 3 pièces brodé or.",   emoji:"◈"},
  {id:4, name:"Robe Wax Élégance",        cat:"femme", artisan:"Fatoumata Koné",   country:"Mali",        price:134,tag:"Bestseller",stock:18,sold:62,desc:"Wax hollandais, ceinture tissée.",emoji:"✦"},
  {id:5, name:"Ensemble Bogolan Chic",    cat:"femme", artisan:"Awa Traoré",       country:"Mali",        price:168,tag:"Artisanal", stock:8, sold:24,desc:"Bogolan peint à la main.",       emoji:"✦"},
  {id:6, name:"Kaftan Soirée Brodé",      cat:"femme", artisan:"Aïcha Diop",       country:"Sénégal",     price:212,tag:"Premium",   stock:6, sold:31,desc:"Voile coton, fils d'or.",        emoji:"✦"},
  {id:7, name:"Mini Boubou Enfant",       cat:"enfant",artisan:"Moussa Diallo",    country:"Sénégal",     price:64, tag:"Populaire", stock:30,sold:55,desc:"Tissu doux, tailles 2–12 ans.",  emoji:"✧"},
  {id:8, name:"Robe Wax Princesse",       cat:"enfant",artisan:"Koffi Mensah",     country:"Togo",        price:52, tag:"Nouveau",   stock:20,sold:38,desc:"Volants wax, 3–10 ans.",         emoji:"✧"},
  {id:9, name:"Ensemble Kente Junior",    cat:"enfant",artisan:"Kweku Mensah",     country:"Ghana",       price:88, tag:"Artisanal", stock:10,sold:22,desc:"Kente authentique tissé main.",   emoji:"✧"},
  {id:10,name:"Masque Ancestral Sénoufo", cat:"art",   artisan:"Cheikh Ndiaye",    country:"Sénégal",     price:320,tag:"Unique",    stock:3, sold:8, desc:"Masque sculpté main, bois venn.", emoji:"◆"},
  {id:11,name:"Sculpture Baobab Bronze",  cat:"art",   artisan:"Cheikh Ndiaye",    country:"Sénégal",     price:445,tag:"Premium",   stock:4, sold:5, desc:"Baobab bronze, socle ébène.",    emoji:"◆"},
  {id:12,name:"Tableau Sahel Acrylique",  cat:"art",   artisan:"Amadou Sow",       country:"Mauritanie",  price:278,tag:"Artisanal", stock:2, sold:11,desc:"Paysage sahélien, acrylique.",    emoji:"◆"},
  {id:13,name:"Collier Perles Krobo",     cat:"divers",artisan:"Abena Asante",     country:"Ghana",       price:86, tag:"Artisanal", stock:15,sold:44,desc:"Perles verre recyclé Krobo.",    emoji:"❋"},
  {id:14,name:"Sac Bogolan Cuir",         cat:"divers",artisan:"Fatoumata Koné",   country:"Mali",        price:112,tag:"Artisanal", stock:9, sold:28,desc:"Bogolan, cuir tannage végétal.",  emoji:"❋"},
  {id:15,name:"Huile de Karité Pure",     cat:"divers",artisan:"Mariam Ouédraogo", country:"Burkina Faso",price:34, tag:"Bio",       stock:50,sold:120,desc:"Karité brut non raffiné, 200ml.",emoji:"❋"},
  {id:16,name:"Tissu Wax 6 yards",        cat:"divers",artisan:"Koffi Mensah",     country:"Togo",        price:58, tag:"Populaire", stock:35,sold:88,desc:"Wax hollandais double face.",     emoji:"❋"},
];
const INIT_A=[
  {id:1,name:"Moussa Diallo",  metier:"Tailleur brodeur",         ville:"Dakar", pays:"Sénégal",flag:"🇸🇳",exp:"23 ans",email:"moussa@artisan.sn", phone:"+221 77 000 001",bio:"Formé par son père, perpétue l'art du grand boubou.",status:"actif",photo:null},
  {id:2,name:"Fatoumata Koné", metier:"Artisane bogolan",         ville:"Bamako",pays:"Mali",   flag:"🇲🇱",exp:"18 ans",email:"fatou@artisan.ml",  phone:"+223 70 000 002",bio:"Ressuscite les motifs anciens du bogolan peint à la boue.",status:"actif",photo:null},
  {id:3,name:"Abena Asante",   metier:"Perlière Krobo",           ville:"Accra", pays:"Ghana",  flag:"🇬🇭",exp:"15 ans",email:"abena@artisan.gh",  phone:"+233 20 000 003",bio:"Dirige une coopérative de 12 femmes artisanes.",status:"actif",photo:null},
  {id:4,name:"Cheikh Ndiaye",  metier:"Sculpteur sur bois",       ville:"Thiès", pays:"Sénégal",flag:"🇸🇳",exp:"30 ans",email:"cheikh@artisan.sn", phone:"+221 76 000 004",bio:"Maître sculpteur, pièces uniques en bois de venn.",status:"actif",photo:null},
  {id:5,name:"Kweku Mensah",   metier:"Tisserand kente",          ville:"Kumasi",pays:"Ghana",  flag:"🇬🇭",exp:"25 ans",email:"kweku@artisan.gh",  phone:"+233 24 000 005",bio:"Tisserand royal, gardien de la tradition Ashanti.",status:"actif",photo:null},
  {id:6,name:"Aïcha Diop",     metier:"Couturière haute couture", ville:"Dakar", pays:"Sénégal",flag:"🇸🇳",exp:"20 ans",email:"aicha@artisan.sn",  phone:"+221 78 000 006",bio:"Allie couture africaine et tendances modernes.",status:"actif",photo:null},
];
const INIT_O=[
  {id:"BDR-2025-0042",date:"2025-01-10",status:"transit",    client:"Mamadou Diallo",  email:"mamadou@email.com",total:355.25,payMethod:"Interac",items:[{name:"Grand Boubou Brodé",qty:1,price:189},{name:"Robe Wax Élégance",qty:1,price:134}]},
  {id:"BDR-2025-0038",date:"2025-01-08",status:"delivered",  client:"Aminata Sow",     email:"aminata@email.com", total:188.50,payMethod:"Carte",  items:[{name:"Kaftan Soirée Brodé",qty:1,price:212}]},
  {id:"BDR-2025-0035",date:"2025-01-05",status:"preparation",client:"Oumar Ba",        email:"oumar@email.com",   total:212.00,payMethod:"PayPal", items:[{name:"Kaftan Soirée Brodé",qty:1,price:212}]},
  {id:"BDR-2025-0031",date:"2025-01-02",status:"delivered",  client:"Sophie Martin",   email:"sophie@email.com",  total:445.75,payMethod:"Interac",items:[{name:"Sculpture Baobab Bronze",qty:1,price:445}]},
  {id:"BDR-2025-0028",date:"2024-12-28",status:"delivered",  client:"Fatima Al-Rashid",email:"fatima@email.com",  total:124.20,payMethod:"Carte",  items:[{name:"Tissu Wax 6 yards",qty:2,price:58}]},
];
const INIT_REQ=[
  {id:1,name:"Ibrahim Coulibaly",metier:"Tisserand bogolan",     pays:"Côte d'Ivoire",email:"ibrahim@artisan.ci",phone:"+225 01 234 567",msg:"Bogolans depuis 15 ans.",date:"2025-01-12",status:"pending"},
  {id:2,name:"Mariama Baldé",    metier:"Bijoutière traditionnelle",pays:"Guinée",   email:"mariama@artisan.gn",phone:"+224 62 345 678",msg:"Bijoux Peul depuis 20 ans.",date:"2025-01-08",status:"pending"},
];
const STATUS_LABELS={confirmed:"✓ Commande confirmée",preparation:"◈ En préparation",shipped:"⊡ Expédiée",transit:"→ En transit",customs:"◆ Dédouanement",delivery:"→ En livraison",delivered:"✦ Livrée !"};
const INIT_EMAIL_LOG=[
  {id:1,type:"commande",   to:"mamadou@email.com",   client:"Mamadou Diallo",  subject:"✅ Commande BADAOUR confirmée — BDR-2025-0042",   date:"2025-01-10 14:23",orderId:"BDR-2025-0042",status:"sent"},
  {id:2,type:"suivi",      to:"mamadou@email.com",   client:"Mamadou Diallo",  subject:"⊡ BADAOUR — BDR-2025-0042 : En transit →",        date:"2025-01-16 09:11",orderId:"BDR-2025-0042",status:"sent"},
  {id:3,type:"bienvenue",  to:"aminata@email.com",   client:"Aminata Sow",     subject:"✦ Bienvenue chez BADAOUR, Aminata !",               date:"2025-01-07 10:05",orderId:null,           status:"sent"},
  {id:4,type:"commande",   to:"aminata@email.com",   client:"Aminata Sow",     subject:"✅ Commande BADAOUR confirmée — BDR-2025-0038",      date:"2025-01-08 11:44",orderId:"BDR-2025-0038",status:"sent"},
  {id:5,type:"suivi",      to:"oumar@email.com",     client:"Oumar Ba",        subject:"⊡ BADAOUR — BDR-2025-0035 : En préparation ◈",    date:"2025-01-06 08:30",orderId:"BDR-2025-0035",status:"sent"},
  {id:6,type:"commande",   to:"sophie@email.com",    client:"Sophie Martin",   subject:"✅ Commande BADAOUR confirmée — BDR-2025-0031",      date:"2025-01-02 16:55",orderId:"BDR-2025-0031",status:"sent"},
  {id:7,type:"bienvenue",  to:"sophie@email.com",    client:"Sophie Martin",   subject:"✦ Bienvenue chez BADAOUR, Sophie !",                date:"2025-01-01 09:20",orderId:null,           status:"sent"},
];

/* ══ ATOMS ════════════════════════════════════════════════════════════════ */
function Btn({children,onClick,gold,danger,outline,sm,full,disabled,style:sx}){
  const bg=disabled?"#E8E2D8":gold?G:danger?"rgba(139,26,0,.1)":outline?"transparent":DARK;
  const cl=gold?DARK:danger?RED:outline?G:"white";
  const bd=outline?`1.5px solid ${G}`:danger?`1px solid rgba(139,26,0,.25)`:"none";
  return(<button disabled={disabled} onClick={onClick} className="ibtn"
    style={{background:bg,color:cl,border:bd,borderRadius:50,padding:sm?"7px 18px":"11px 24px",
      fontSize:sm?11:13,fontWeight:600,fontFamily:SAN,width:full?"100%":undefined,
      opacity:disabled?.5:1,cursor:disabled?"not-allowed":"pointer",letterSpacing:.3,...sx}}>{children}</button>);
}
function Field({label,children}){
  return(<div style={{marginBottom:14}}>
    <label style={{display:"block",fontSize:10,fontWeight:700,color:MUT,textTransform:"uppercase",letterSpacing:1.2,marginBottom:5,fontFamily:SAN}}>{label}</label>
    {children}
  </div>);
}
function Inp({value,onChange,placeholder,type="text",rows,defaultValue}){
  const st={width:"100%",padding:"11px 16px",background:"white",border:`1.5px solid ${BDR}`,borderRadius:10,fontSize:13,color:DARK,outline:"none",fontFamily:SAN,transition:"border-color .15s"};
  if(rows) return <textarea value={value} onChange={onChange} placeholder={placeholder} rows={rows} style={{...st,resize:"vertical"}}/>;
  return <input type={type} value={value} defaultValue={defaultValue} onChange={onChange} placeholder={placeholder} style={st}/>;
}
function Sel({value,onChange,options}){
  return(<select value={value} onChange={onChange}
    style={{width:"100%",padding:"11px 16px",background:"white",border:`1.5px solid ${BDR}`,borderRadius:10,fontSize:13,color:DARK,outline:"none",fontFamily:SAN}}>
    {options.map(o=>{const val=Array.isArray(o)?o[0]:o;const lbl=Array.isArray(o)?o[1]:o;return <option key={val} value={val}>{lbl}</option>;})}
  </select>);
}
function Badge({text}){
  const C={Bestseller:"#B8860B",Nouveau:GREEN,Artisanal:"#8B4513",Populaire:RED,Unique:"#6A0572",Bio:GREEN,Premium:"#1A3A6B",actif:GREEN,inactif:"#999",pending:"#B8860B",approved:GREEN,rejected:RED,confirmed:GREEN,preparation:"#8B4513",shipped:"#1A5276",transit:"#6A0572",customs:"#B7950B",delivery:"#1A5276",delivered:GREEN,sent:"#1E7A4A",commande:"#1A3A6B",bienvenue:"#6A0572",suivi:"#8B4513",custom:MUT};
  const c=C[text]||MUT;
  return(<span style={{background:c+"22",color:c,padding:"3px 12px",borderRadius:20,fontSize:11,fontWeight:700,border:`1px solid ${c}44`,fontFamily:SAN,whiteSpace:"nowrap"}}>{text}</span>);
}
function KPI({icon,label,value,sub,color}){
  return(<div className="kpi-card" style={{background:"white",borderRadius:14,padding:"20px 22px",borderLeft:`4px solid ${color||G}`,boxShadow:"0 2px 16px rgba(0,0,0,.06)",border:`1px solid #E8E2D8`,borderLeftWidth:4,borderLeftColor:color||G}}>
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
      <span style={{fontSize:26}}>{icon}</span>
      <span style={{fontSize:24,fontWeight:700,color:DARK,fontFamily:S,lineHeight:1}}>{value}</span>
    </div>
    <div style={{fontSize:13,fontWeight:600,color:DARK,fontFamily:SAN,marginBottom:3}}>{label}</div>
    {sub&&<div style={{fontSize:11,color:MUT,fontFamily:SAN}}>{sub}</div>}
  </div>);
}
function Toast({msg,onClose}){
  useEffect(()=>{if(msg){const t=setTimeout(onClose,3200);return()=>clearTimeout(t);}},[msg,onClose]);
  if(!msg)return null;
  return(<div style={{position:"fixed",bottom:28,left:"50%",transform:"translateX(-50%)",background:DARK,color:"white",padding:"12px 24px",borderRadius:50,fontSize:13,fontFamily:SAN,fontWeight:500,zIndex:9999,boxShadow:"0 8px 28px rgba(0,0,0,.3)",animation:"toast .3s ease",whiteSpace:"nowrap",display:"flex",alignItems:"center",gap:10}}>
    <span style={{color:G}}>✦</span>{msg}
  </div>);
}
function Modal({title,onClose,children,wide,xl}){
  return(<div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.45)",zIndex:500,display:"flex",alignItems:"center",justifyContent:"center",padding:16}} onClick={e=>{if(e.target===e.currentTarget)onClose();}}>
    <div style={{background:"white",borderRadius:18,width:"100%",maxWidth:xl?860:wide?660:520,maxHeight:"94vh",overflowY:"auto",boxShadow:"0 28px 70px rgba(0,0,0,.28)"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"16px 24px",borderBottom:`1px solid ${BDR}`,position:"sticky",top:0,background:"white",zIndex:1}}>
        <h2 style={{fontSize:18,fontWeight:700,color:DARK,fontFamily:S}}>{title}</h2>
        <button onClick={onClose} className="ibtn" style={{background:"none",border:"none",fontSize:22,color:MUT,lineHeight:1,cursor:"pointer"}}>×</button>
      </div>
      <div style={{padding:"20px 24px"}}>{children}</div>
    </div>
  </div>);
}
function Confirm({msg,onOk,onCancel}){
  return(<div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.45)",zIndex:600,display:"flex",alignItems:"center",justifyContent:"center",padding:20}}>
    <div style={{background:"white",borderRadius:16,padding:"32px",maxWidth:340,width:"100%",textAlign:"center",boxShadow:"0 20px 50px rgba(0,0,0,.25)"}}>
      <div style={{fontSize:36,marginBottom:12}}>⚠️</div>
      <p style={{fontSize:15,color:DARK,fontFamily:SAN,marginBottom:24,fontWeight:500}}>{msg}</p>
      <div style={{display:"flex",gap:10,justifyContent:"center"}}>
        <Btn outline onClick={onCancel}>Annuler</Btn>
        <button onClick={onOk} style={{background:RED,color:"white",border:"none",borderRadius:50,padding:"10px 22px",fontSize:13,fontWeight:600,fontFamily:SAN,cursor:"pointer"}}>Supprimer</button>
      </div>
    </div>
  </div>);
}

/* ══ EMAIL PREVIEW MODAL ══════════════════════════════════════════════════ */
function EmailPreview({email,onClose}){
  const typeLabel={commande:"⊡ Confirmation commande",bienvenue:"✦ Email de bienvenue",suivi:"◆ Mise à jour suivi",custom:"✉ Email personnalisé"};
  const typeColor={commande:GREEN,bienvenue:"#6A0572",suivi:"#8B4513",custom:MUT};
  const c=typeColor[email.type]||MUT;
  return(
    <Modal title={`Aperçu email — ${typeLabel[email.type]||"Email"}`} onClose={onClose} xl>
      {/* Email meta */}
      <div style={{background:"#FDFAF4",borderRadius:10,padding:"14px 18px",marginBottom:18,border:`1px solid ${BDR}`}}>
        <div style={{display:"grid",gridTemplateColumns:"auto 1fr",gap:"6px 14px",fontSize:12,fontFamily:SAN}}>
          {[["De","service@badaour.com (BADAOUR)"],["À",email.to],["Sujet",email.subject],["Envoyé",email.date||new Date().toLocaleString("fr-CA")]].map(([l,v])=>(
            <><span key={l+"l"} style={{fontWeight:700,color:MUT,textTransform:"uppercase",fontSize:9,letterSpacing:1,paddingTop:2}}>{l}</span>
            <span key={l+"v"} style={{color:DARK,wordBreak:"break-word"}}>{v}</span></>
          ))}
        </div>
      </div>

      {/* Email body rendered */}
      <div style={{border:`1px solid ${BDR}`,borderRadius:12,overflow:"hidden"}}>
        {/* Header */}
        <div style={{background:DARK,padding:"28px 36px",textAlign:"center"}}>
          <div style={{fontSize:26,fontWeight:900,color:G,letterSpacing:6,fontFamily:S,marginBottom:4}}>BADAOUR</div>
          <div style={{fontSize:9,color:"rgba(201,168,76,.5)",letterSpacing:4,fontFamily:SAN,textTransform:"uppercase"}}>L'AFRIQUE À VOTRE PORTE · MONTRÉAL, CANADA</div>
        </div>

        {/* Body */}
        <div style={{padding:"32px 36px",background:"white"}}>
          {/* Greeting banner */}
          <div style={{background:c+"14",border:`1px solid ${c}33`,borderRadius:10,padding:"16px 20px",marginBottom:22,textAlign:"center"}}>
            <div style={{fontSize:20,marginBottom:6}}>
              {email.type==="commande"?"✓":email.type==="bienvenue"?"✦":email.type==="suivi"?"⊡":"✉"}
            </div>
            <div style={{fontSize:18,fontWeight:700,color:DARK,fontFamily:S}}>
              {email.type==="commande"&&"Commande confirmée !"}
              {email.type==="bienvenue"&&`Bienvenue, ${email.client?.split(" ")[0]} !`}
              {email.type==="suivi"&&"Mise à jour de votre commande"}
              {email.type==="custom"&&(email.subject||"Message de BADAOUR")}
            </div>
          </div>

          <p style={{fontSize:14,color:"#333",fontFamily:SAN,marginBottom:16,lineHeight:1.7}}>
            Bonjour <strong>{email.client}</strong>,
          </p>

          {email.type==="commande"&&<>
            <p style={{fontSize:13,color:"#555",fontFamily:SAN,lineHeight:1.8,marginBottom:18}}>
              Merci pour votre confiance ! Votre commande a bien été reçue et est en cours de traitement.
            </p>
            <div style={{background:"#FDFCF9",borderRadius:10,padding:"16px 20px",marginBottom:18,border:`1px solid ${BDR}`}}>
              <div style={{fontSize:12,fontWeight:700,color:DARK,marginBottom:12,fontFamily:SAN}}>⊡ Détails de la commande</div>
              {[["N° commande",email.orderId||"BDR-2025-XXXX"],["Livraison","14 à 21 jours ouvrables"],["Mode de paiement",email.payMethod||"À confirmer"],["Frais de livraison","18,00 $CA"]].map(([k,v])=>(
                <div key={k} style={{display:"flex",justifyContent:"space-between",borderBottom:`1px dashed ${BDR}`,padding:"6px 0",fontSize:12,fontFamily:SAN}}>
                  <span style={{color:MUT}}>{k}</span><span style={{fontWeight:600,color:DARK}}>{v}</span>
                </div>
              ))}
            </div>
            <p style={{fontSize:12,color:MUT,fontFamily:SAN,lineHeight:1.8,marginBottom:18}}>
              Vous recevrez une notification à chaque étape : préparation, expédition, transit et livraison.
            </p>
          </>}

          {email.type==="bienvenue"&&<>
            <p style={{fontSize:13,color:"#555",fontFamily:SAN,lineHeight:1.8,marginBottom:18}}>
              Vous faites maintenant partie de la famille BADAOUR. Découvrez nos créations artisanales africaines, livrées directement chez vous à Montréal.
            </p>
            <div style={{background:"#FDFCF9",borderRadius:10,padding:"16px 20px",marginBottom:18}}>
              {[["◈","Habillement traditionnel authentique"],["◆","Sculptures, masques et œuvres d'art"],["→","Livraison Afrique → Canada en 14–21 jours"],["◆","Commerce éthique, artisans rémunérés justement"]].map(([icon,text])=>(
                <div key={text} style={{display:"flex",gap:10,alignItems:"center",padding:"6px 0",fontSize:12,color:"#444",fontFamily:SAN}}>
                  <span>{icon}</span><span>{text}</span>
                </div>
              ))}
            </div>
          </>}

          {email.type==="suivi"&&<>
            <p style={{fontSize:13,color:"#555",fontFamily:SAN,lineHeight:1.8,marginBottom:18}}>
              Votre commande <strong>{email.orderId}</strong> vient de changer de statut.
            </p>
            <div style={{background:c+"14",border:`1px solid ${c}33`,borderRadius:10,padding:"16px 20px",marginBottom:18,textAlign:"center"}}>
              <div style={{fontSize:16,fontWeight:700,color:c,fontFamily:SAN}}>{email.newStatus||STATUS_LABELS[email.statusKey]||"Statut mis à jour"}</div>
            </div>
          </>}

          {email.type==="custom"&&<>
            <div style={{fontSize:13,color:"#555",fontFamily:SAN,lineHeight:1.8,marginBottom:18,whiteSpace:"pre-wrap"}}>
              {email.body||"(Corps du message)"}
            </div>
          </>}

          {/* CTA */}
          <div style={{textAlign:"center",margin:"24px 0"}}>
            <div style={{display:"inline-block",background:G,color:DARK,padding:"13px 36px",borderRadius:50,fontSize:13,fontWeight:700,fontFamily:SAN}}>
              {email.type==="bienvenue"?"DÉCOUVRIR LA BOUTIQUE →":email.type==="suivi"?"SUIVRE MA COMMANDE →":"VOIR MA COMMANDE →"}
            </div>
          </div>

          <div style={{borderTop:`1px solid ${BDR}`,paddingTop:16,fontSize:12,color:MUT,fontFamily:SAN,lineHeight:1.8}}>
            Des questions ? Nous sommes là :<br/>
            ✆ {PHONE} · ✉ {EMAIL}
          </div>
        </div>

        {/* Footer */}
        <div style={{background:"#1A1714",padding:"16px 36px",textAlign:"center"}}>
          <div style={{fontSize:11,color:"rgba(212,175,55,.6)",fontFamily:SAN}}>BADAOUR · Commerce éthique · Artisanat africain authentique</div>
          <div style={{fontSize:10,color:"rgba(212,175,55,.35)",marginTop:4,fontFamily:SAN}}>Montréal, Québec, Canada · {EMAIL}</div>
        </div>
      </div>

      <div style={{display:"flex",gap:10,marginTop:18,justifyContent:"flex-end"}}>
        <Btn outline onClick={onClose}>Fermer</Btn>
        <Btn gold onClick={()=>{navigator.clipboard?.writeText(email.subject);onClose();}}>◈ Copier le sujet</Btn>
      </div>
    </Modal>
  );
}

/* ══ WHATSAPP GENERATOR ═══════════════════════════════════════════════════ */
function WAGenerator({artisans,orders,onClose}){
  const [art,setArt]=useState(artisans[0]?.id||"");
  const [ord,setOrd]=useState(orders[0]?.id||"");
  const [type,setType]=useState("commande");
  const [msg,setMsg]=useState("");
  const [copied,setCopied]=useState(false);

  const artisan=artisans.find(a=>a.id===parseInt(art)||a.id===art);
  const order=orders.find(o=>o.id===ord);

  const genMsg=()=>{
    if(!artisan||!order) return;
    const items=order.items?.map(i=>`• ${i.name} × ${i.qty}`).join("\n")||"• Articles à confirmer";
    const msgs={
      commande:`Bonjour ${artisan.name.split(" ")[0]} ✦\n\nNouvelle commande BADAOUR #${order.id} !\n\n${items}\n\nClient : ${order.client}\nTotal : ${order.total} $CA\n\nPouvez-vous confirmer la disponibilité et le délai de confection ?\n\nMerci ! ✦\nBADAOUR - ${PHONE}`,
      suivi:`Bonjour ${artisan.name.split(" ")[0]} ✦\n\nSuivi commande #${order.id} — Client : ${order.client}\n\nStatut actuel : ${STATUS_LABELS[order.status]||order.status}\n\nPouvez-vous me confirmer :\n• Date d'expédition prévue ?\n• Numéro de tracking DHL ?\n\nMerci d'avance ! ✦\nBADAOUR`,
      paiement:`Bonjour ${artisan.name.split(" ")[0]} ✦\n\nConfirmation de paiement pour la commande #${order.id}.\n\nMontant artisan : à confirmer\nMode : virement Western Union / Orange Money\n\nVeuillez confirmer vos coordonnées bancaires.\n\nMerci ! ✦\nBADAOUR`,
    };
    setMsg(msgs[type]||"");
  };

  useEffect(()=>{genMsg();},[art,ord,type]);

  const phone=artisan?.phone?.replace(/[\s\-+]/g,"")||"";
  const waUrl=`https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;

  return(
    <Modal title="✆ Générateur WhatsApp Artisan" onClose={onClose} wide>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:16}}>
        <Field label="Artisan">
          <Sel value={art} onChange={e=>setArt(e.target.value)} options={artisans.map(a=>[a.id,`${a.flag} ${a.name}`])}/>
        </Field>
        <Field label="Commande">
          <Sel value={ord} onChange={e=>setOrd(e.target.value)} options={orders.map(o=>[o.id,`${o.id} — ${o.client}`])}/>
        </Field>
      </div>
      <Field label="Type de message">
        <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
          {[["commande","⊡ Nouvelle commande"],["suivi","⌕ Suivi"],["paiement","◆ Paiement"]].map(([k,l])=>(
            <button key={k} onClick={()=>setType(k)} className="ibtn"
              style={{padding:"7px 16px",borderRadius:50,border:`1px solid ${type===k?G:BDR}`,background:type===k?G:"white",color:type===k?DARK:MUT,fontSize:12,fontFamily:SAN,fontWeight:type===k?700:400,cursor:"pointer"}}>
              {l}
            </button>
          ))}
        </div>
      </Field>
      {artisan&&(
        <div style={{background:"#FDFCF9",borderRadius:8,padding:"10px 14px",marginBottom:12,fontSize:11,color:MUT,fontFamily:SAN,display:"flex",gap:8,flexWrap:"wrap"}}>
          <span>◉ {artisan.name}</span>
          <span>✆ {artisan.phone}</span>
          <span>◆ {artisan.ville}, {artisan.pays}</span>
        </div>
      )}
      <Field label="Message généré (modifiable)">
        <textarea value={msg} onChange={e=>setMsg(e.target.value)} rows={10}
          style={{width:"100%",padding:"12px",background:"#FDFAF4",border:`1.5px solid ${BDR}`,borderRadius:8,fontSize:12,color:DARK,outline:"none",fontFamily:"monospace",resize:"vertical"}}/>
      </Field>
      <div style={{display:"flex",gap:10,flexWrap:"wrap",justifyContent:"flex-end"}}>
        <Btn outline onClick={()=>{navigator.clipboard?.writeText(msg);setCopied(true);setTimeout(()=>setCopied(false),2000);}}>
          {copied?"✓ Copié !":"◈ Copier"}
        </Btn>
        <a href={waUrl} target="_blank" rel="noreferrer"
          style={{background:"#25D366",color:"white",borderRadius:50,padding:"10px 22px",fontSize:13,fontWeight:700,fontFamily:SAN,textDecoration:"none",display:"inline-flex",alignItems:"center",gap:8}}>
          ✆ Ouvrir WhatsApp
        </a>
      </div>
    </Modal>
  );
}

/* ══ AI EMAIL COMPOSER ════════════════════════════════════════════════════ */
function AIComposer({clients,orders,onSend,onClose}){
  const [to,setTo]=useState("");
  const [subject,setSubject]=useState("");
  const [body,setBody]=useState("");
  const [aiPrompt,setAiPrompt]=useState("");
  const [loading,setLoading]=useState(false);
  const [tab,setTab]=useState("composer");
  const [template,setTemplate]=useState("custom");

  const applyTemplate=t=>{
    setTemplate(t);
    const c=clients[0];
    const o=orders[0];
    const tpls={
      commande:{subject:`✅ Commande BADAOUR confirmée — ${o?.id||"BDR-XXXX"}`,body:`Bonjour ${c?.name||"[Prénom]"},\n\nMerci pour votre commande #${o?.id||"BDR-XXXX"} passée le ${o?.date||"[date]"}.\n\nVotre colis sera préparé par nos artisans et expédié sous 3–5 jours ouvrables.\nDélai de livraison : 14 à 21 jours.\n\nNous vous tiendrons informé à chaque étape.\n\nCordialement,\nL'équipe BADAOUR\n${EMAIL} · ${PHONE}`},
      bienvenue:{subject:`✦ Bienvenue chez BADAOUR, ${c?.name?.split(" ")[0]||"[Prénom]"} !`,body:`Bonjour ${c?.name||"[Prénom]"},\n\nBienvenue dans la famille BADAOUR !\n\nVous pouvez dès maintenant découvrir notre boutique et commander des créations africaines authentiques livrées chez vous au Canada.\n\n✨ Commerce éthique · Artisans rémunérés justement · Livraison Afrique → Canada\n\nCordialement,\nL'équipe BADAOUR`},
      promo:{subject:`✦ Offre spéciale BADAOUR — Livraison offerte ce weekend !`,body:`Bonjour ${c?.name||"[Prénom]"},\n\nCe weekend seulement : la livraison est offerte sur toutes vos commandes !\n\nProfitez-en pour découvrir nos nouveautés : robes wax, boubous brodés, sculptures uniques...\n\nCode promo : BADAOUR-FREE\nValable jusqu'au [date]\n\nCordialement,\nL'équipe BADAOUR`},
      suivi:{subject:`⊡ BADAOUR — Commande ${o?.id||"BDR-XXXX"} : ${STATUS_LABELS[o?.status]||"En cours"}`,body:`Bonjour ${c?.name||"[Prénom]"},\n\nBonne nouvelle ! Votre commande #${o?.id||"BDR-XXXX"} vient de changer de statut.\n\nStatut actuel : ${STATUS_LABELS[o?.status]||"En cours"}\n\nSuivez votre commande en temps réel sur badaour.com\n\nCordialement,\nL'équipe BADAOUR`},
    };
    const tpl=tpls[t];
    if(tpl){setSubject(tpl.subject);setBody(tpl.body);if(c)setTo(c.email||"");}
  };

  const generateWithAI=async()=>{
    if(!aiPrompt.trim()) return;
    setLoading(true);
    try{
      const res=await fetch("https://api.anthropic.com/v1/messages",{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          model:"claude-sonnet-4-20250514",
          max_tokens:1000,
          messages:[{role:"user",content:`Tu es le rédacteur email de la boutique BADAOUR (commerce de produits artisanaux africains, basé à Montréal). Génère un email professionnel, chaleureux, en français canadien.\n\nConsigne : ${aiPrompt}\n\nRéponds UNIQUEMENT en JSON: {"subject":"...","body":"..."}\n\nPas de markdown, pas d'explication, juste le JSON.`}]
        })
      });
      const data=await res.json();
      const text=data.content?.[0]?.text||"{}";
      const clean=text.replace(/```json|```/g,"").trim();
      const parsed=JSON.parse(clean);
      if(parsed.subject) setSubject(parsed.subject);
      if(parsed.body) setBody(parsed.body);
    }catch(e){console.error(e);}
    setLoading(false);
  };

  return(
    <Modal title="✉ Compositeur d'Email" onClose={onClose} xl>
      <div style={{display:"flex",gap:8,marginBottom:16,flexWrap:"wrap"}}>
        {[["composer","✏️ Composer"],["ia","◈ IA"],["templates","◈ Templates"]].map(([k,l])=>(
          <button key={k} onClick={()=>setTab(k)} className="ibtn"
            style={{padding:"8px 20px",borderRadius:50,border:`1px solid ${tab===k?G:BDR}`,background:tab===k?G:"white",color:tab===k?DARK:MUT,fontSize:12,fontFamily:SAN,fontWeight:tab===k?700:400,cursor:"pointer"}}>
            {l}
          </button>
        ))}
      </div>

      {tab==="ia"&&(
        <div style={{background:"#FDFAF4",borderRadius:12,padding:20,marginBottom:16,border:`1px solid ${BDR}`}}>
          <div style={{fontSize:13,fontWeight:600,color:DARK,fontFamily:SAN,marginBottom:10}}>◈ Génération IA</div>
          <p style={{fontSize:11,color:MUT,fontFamily:SAN,marginBottom:12}}>Décrivez l'email que vous souhaitez et l'IA le rédige automatiquement.</p>
          <Field label="Votre demande">
            <Inp value={aiPrompt} onChange={e=>setAiPrompt(e.target.value)} placeholder="ex: Email pour remercier un client fidèle qui vient de passer sa 3ème commande, lui offrir -10% sur la prochaine..." rows={3}/>
          </Field>
          <Btn gold onClick={generateWithAI} disabled={loading||!aiPrompt.trim()}>
            {loading?<span className="spin" style={{display:"inline-block"}}>⏳</span>:"◈ Générer avec l'IA"}
          </Btn>
          {(subject||body)&&<div style={{marginTop:12,padding:"10px 14px",background:"#e8f7e8",borderRadius:8,fontSize:11,color:GREEN,fontFamily:SAN,fontWeight:600}}>✅ Email généré ! Allez dans l'onglet "Composer" pour modifier et envoyer.</div>}
        </div>
      )}

      {tab==="templates"&&(
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:16}}>
          {[["commande","⊡ Confirmation commande","Envoyé après chaque commande"],["bienvenue","✦ Email de bienvenue","Lors de l'inscription"],["suivi","◆ Mise à jour suivi","Changement de statut"],["promo","✦ Offre promotionnelle","Campagne marketing"]].map(([k,icon,desc])=>(
            <div key={k} onClick={()=>{applyTemplate(k);setTab("composer");}}
              className="ibtn" style={{background:template===k?"rgba(212,175,55,.1)":"#FDFAF4",
                border:`2px solid ${template===k?G:BDR}`,borderRadius:10,padding:"14px 16px",cursor:"pointer"}}>
              <div style={{fontSize:14,fontWeight:700,color:DARK,fontFamily:SAN,marginBottom:4}}>{icon}</div>
              <div style={{fontSize:11,color:MUT,fontFamily:SAN}}>{desc}</div>
            </div>
          ))}
        </div>
      )}

      {(tab==="composer"||(subject||body))&&(
        <div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <Field label="Destinataire">
              <div>
                <Inp value={to} onChange={e=>setTo(e.target.value)} placeholder="client@email.com" list="client-list"/>
                <datalist id="client-list">{clients.map(c=><option key={c.email} value={c.email}/>)}</datalist>
              </div>
            </Field>
            <Field label="Type">
              <Sel value={template} onChange={e=>setTemplate(e.target.value)} options={[["custom","✉ Personnalisé"],["commande","⊡ Confirmation"],["bienvenue","✦ Bienvenue"],["suivi","◆ Suivi"],["promo","✦ Promo"]]}/>
            </Field>
          </div>
          <Field label="Sujet"><Inp value={subject} onChange={e=>setSubject(e.target.value)} placeholder="Objet de l'email..."/></Field>
          <Field label="Corps du message"><Inp value={body} onChange={e=>setBody(e.target.value)} rows={8} placeholder="Votre message..."/></Field>
        </div>
      )}

      <div style={{display:"flex",gap:10,justifyContent:"flex-end",paddingTop:14,borderTop:`1px solid ${BDR}`}}>
        <Btn outline onClick={onClose}>Annuler</Btn>
        <Btn gold disabled={!to||!subject||!body} onClick={()=>{
          onSend({type:template,to,subject,body,client:clients.find(c=>c.email===to)?.name||to,date:new Date().toLocaleString("fr-CA")});
          onClose();
        }}>✉ Envoyer l'email</Btn>
      </div>
    </Modal>
  );
}

/* ══ PHOTO MANAGER ════════════════════════════════════════════════════════ */
function PhotoManager({photos,onChange}){
  const fileRef=useRef();
  const addPhoto=e=>{
    const file=e.target.files[0];if(!file)return;
    if(photos.length>=MAX_PHOTOS){alert(`Maximum ${MAX_PHOTOS} photos`);e.target.value="";return;}
    const r=new FileReader();r.onload=ev=>onChange([...photos,ev.target.result]);r.readAsDataURL(file);e.target.value="";
  };
  const remove=idx=>onChange(photos.filter((_,i)=>i!==idx));
  const move=(idx,dir)=>{const a=[...photos];const to=idx+dir;if(to<0||to>=a.length)return;[a[idx],a[to]]=[a[to],a[idx]];onChange(a);};
  return(
    <div style={{marginBottom:18}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
        <label style={{fontSize:10,fontWeight:700,color:RED,textTransform:"uppercase",letterSpacing:1,fontFamily:SAN}}>Photos ({photos.length}/{MAX_PHOTOS})</label>
        {photos.length>0&&<span style={{fontSize:10,color:MUT,fontFamily:SAN}}>★ 1ère = principale · ◀▶ réordonner</span>}
      </div>
      <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"flex-start"}}>
        {photos.map((ph,i)=>(
          <div key={i} style={{position:"relative",flexShrink:0}}>
            <img src={ph} alt="" style={{width:88,height:88,objectFit:"cover",borderRadius:8,display:"block",border:`2.5px solid ${i===0?G:BDR}`}}/>
            {i===0&&<div style={{position:"absolute",top:-9,left:"50%",transform:"translateX(-50%)",background:G,color:DARK,fontSize:8,fontWeight:800,padding:"2px 7px",borderRadius:10,fontFamily:SAN,whiteSpace:"nowrap"}}>PRINCIPALE</div>}
            <div style={{position:"absolute",bottom:0,left:0,right:0,background:"rgba(0,0,0,.6)",borderRadius:"0 0 6px 6px",display:"flex",justifyContent:"center",gap:2,padding:"4px 2px"}}>
              <button onClick={()=>move(i,-1)} disabled={i===0} className="ibtn" style={{background:"none",border:"none",color:i===0?"rgba(255,255,255,.25)":"white",fontSize:13,cursor:i===0?"default":"pointer",padding:"0 4px",lineHeight:1}}>◀</button>
              <button onClick={()=>remove(i)} className="ibtn" style={{background:"none",border:"none",color:"#ff6b6b",fontSize:13,cursor:"pointer",padding:"0 4px",lineHeight:1}}>✕</button>
              <button onClick={()=>move(i,1)} disabled={i===photos.length-1} className="ibtn" style={{background:"none",border:"none",color:i===photos.length-1?"rgba(255,255,255,.25)":"white",fontSize:13,cursor:i===photos.length-1?"default":"pointer",padding:"0 4px",lineHeight:1}}>▶</button>
            </div>
          </div>
        ))}
        {photos.length<MAX_PHOTOS&&(
          <div onClick={()=>fileRef.current?.click()} className="uzone" style={{width:88,height:88,borderRadius:8,flexShrink:0}}>
            <div style={{textAlign:"center"}}>
              <div style={{fontSize:24,color:G}}>+</div>
              <div style={{fontSize:9,color:G,fontWeight:700,fontFamily:SAN,marginTop:2}}>Ajouter</div>
            </div>
          </div>
        )}
        <input type="file" accept="image/*" ref={fileRef} onChange={addPhoto}/>
      </div>
    </div>
  );
}

/* ══ PRODUCT FORM ═════════════════════════════════════════════════════════ */
function ProductForm({init,artisanNames,onSave,onClose}){
  const [f,setF]=useState(init?{...init}:{name:"",cat:"homme",artisan:"",country:"",price:"",tag:"Nouveau",stock:"",desc:"",emoji:"◈"});
  const [photos,setPhotos]=useState(init?.photos||[]);
  const set=k=>e=>setF(p=>({...p,[k]:typeof e==="string"?e:e.target.value}));
  return(<div>
    <PhotoManager photos={photos} onChange={setPhotos}/>
    <Field label="Nom du produit *"><Inp value={f.name} onChange={set("name")} placeholder="Grand Boubou Brodé"/></Field>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
      <Field label="Catégorie"><Sel value={f.cat} onChange={set("cat")} options={CATS}/></Field>
      <Field label="Tag"><Sel value={f.tag} onChange={set("tag")} options={TAGS}/></Field>
      <Field label="Artisan *">
        <div><Inp value={f.artisan} onChange={set("artisan")} placeholder="Nom artisan" list="art-list"/>
        <datalist id="art-list">{artisanNames.map(n=><option key={n} value={n}/>)}</datalist></div>
      </Field>
      <Field label="Pays"><Inp value={f.country} onChange={set("country")} placeholder="Sénégal"/></Field>
      <Field label="Prix ($CA) *"><Inp type="number" value={f.price} onChange={set("price")} placeholder="0"/></Field>
      <Field label="Stock"><Inp type="number" value={f.stock} onChange={set("stock")} placeholder="0"/></Field>
      <Field label="Emoji"><Inp value={f.emoji} onChange={set("emoji")} placeholder="◈"/></Field>
    </div>
    <Field label="Description"><Inp value={f.desc} onChange={set("desc")} rows={3} placeholder="Description..."/></Field>
    <div style={{display:"flex",gap:10,justifyContent:"flex-end",paddingTop:16,borderTop:`1px solid ${BDR}`}}>
      <Btn outline onClick={onClose}>Annuler</Btn>
      <Btn gold onClick={()=>{
        if(!f.name||!f.price){alert("Nom et prix obligatoires");return;}
        onSave({...f,photos,price:parseFloat(f.price)||0,stock:parseInt(f.stock)||0,sold:f.sold||0,id:f.id||Date.now()});
      }}>{init?"Enregistrer":"Ajouter"}</Btn>
    </div>
  </div>);
}

/* ══ ARTISAN FORM ═════════════════════════════════════════════════════════ */
function ArtisanForm({init,onSave,onClose}){
  const [f,setF]=useState(init?{...init}:{name:"",metier:"",ville:"",pays:"",flag:"✦",exp:"",email:"",phone:"",bio:"",status:"actif"});
  const [photo,setPhoto]=useState(init?.photo||null);
  const ref=useRef();
  const set=k=>e=>setF(p=>({...p,[k]:typeof e==="string"?e:e.target.value}));
  return(<div>
    <div style={{display:"flex",gap:16,marginBottom:18,alignItems:"flex-start"}}>
      <div style={{flexShrink:0}}>
        <div onClick={()=>ref.current?.click()} className="uzone" style={{width:88,height:88,borderRadius:"50%",overflow:"hidden"}}>
          {photo?<img src={photo} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}}/>:<div style={{textAlign:"center"}}><div style={{fontSize:20,color:G}}>◉</div><div style={{fontSize:9,color:G,fontWeight:700,fontFamily:SAN,marginTop:2}}>Photo</div></div>}
        </div>
        <input type="file" accept="image/*" ref={ref} onChange={e=>{const file=e.target.files[0];if(!file)return;const r=new FileReader();r.onload=ev=>setPhoto(ev.target.result);r.readAsDataURL(file);}}/>
      </div>
      <div style={{flex:1}}>
        <Field label="Nom complet *"><Inp value={f.name} onChange={set("name")} placeholder="Moussa Diallo"/></Field>
        <Field label="Métier *"><Inp value={f.metier} onChange={set("metier")} placeholder="Tailleur brodeur"/></Field>
      </div>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
      <Field label="Ville"><Inp value={f.ville} onChange={set("ville")} placeholder="Dakar"/></Field>
      <Field label="Pays"><Inp value={f.pays} onChange={set("pays")} placeholder="Sénégal"/></Field>
      <Field label="Expérience"><Inp value={f.exp} onChange={set("exp")} placeholder="15 ans"/></Field>
      <Field label="Drapeau"><Inp value={f.flag} onChange={set("flag")} placeholder="🇸🇳"/></Field>
      <Field label="Email"><Inp type="email" value={f.email} onChange={set("email")} placeholder="artisan@email.com"/></Field>
      <Field label="Téléphone / WhatsApp"><Inp value={f.phone} onChange={set("phone")} placeholder="+221 77 000 000"/></Field>
      <Field label="Statut"><Sel value={f.status} onChange={set("status")} options={[["actif","✅ Actif"],["inactif","⏸ Inactif"]]}/></Field>
    </div>
    <Field label="Bio"><Inp value={f.bio} onChange={set("bio")} rows={3} placeholder="Présentez l'artisan..."/></Field>
    <div style={{display:"flex",gap:10,justifyContent:"flex-end",paddingTop:16,borderTop:`1px solid ${BDR}`}}>
      <Btn outline onClick={onClose}>Annuler</Btn>
      <Btn gold onClick={()=>{if(!f.name||!f.metier){alert("Obligatoires");return;}onSave({...f,photo,id:f.id||Date.now(),produits:f.produits||0});}}>{init?"Enregistrer":"Ajouter"}</Btn>
    </div>
  </div>);
}

/* ══ SIDEBAR ══════════════════════════════════════════════════════════════ */
function Sidebar({page,setPage,onLogout,pendingR,pendingO,newEmails}){
  const links=[
    {k:"dashboard",   l:"Dashboard",      i:"◈"},
    {k:"orders",      l:"Commandes",      i:"⊡",n:pendingO},
    {k:"products",    l:"Produits",       i:"◈"},
    {k:"artisans",    l:"Artisans",       i:"✦",n:pendingR},
    {k:"clients",     l:"Clients",        i:"◉"},
    {k:"communications",l:"Communications",i:"✉",n:newEmails},
    {k:"settings",    l:"Paramètres",     i:"◆"},
  ];
  return(
    <aside style={{width:224,background:DARK,display:"flex",flexDirection:"column",height:"100vh",flexShrink:0,position:"sticky",top:0,overflowY:"auto"}}>
      <div style={{padding:"22px 18px 16px",borderBottom:"1px solid rgba(201,168,76,.15)"}}>
        <div style={{fontSize:24,fontWeight:900,color:G,letterSpacing:4,fontFamily:S}}>BADAOUR</div>
        <div style={{fontSize:9,color:"rgba(201,168,76,.45)",letterSpacing:3,marginTop:2,fontFamily:SAN,textTransform:"uppercase"}}>Administration</div>
      </div>
      <nav style={{padding:"10px 0",flex:1}}>
        {links.map(({k,l,i,n})=>(
          <button key={k} onClick={()=>setPage(k)} className={`snav${page===k?" on":""}`}
            style={{display:"flex",alignItems:"center",gap:10,width:"100%",padding:"11px 18px",background:"none",border:"none",cursor:"pointer",color:"rgba(255,255,255,.55)",fontSize:13,fontFamily:SAN,textAlign:"left",borderLeft:"3px solid transparent"}}>
            <span style={{fontSize:16}}>{i}</span>
            <span style={{flex:1}}>{l}</span>
            {n>0&&<span style={{background:k==="communications"?"#1A5276":RED,color:"white",fontSize:10,fontWeight:700,borderRadius:10,padding:"1px 7px"}}>{n}</span>}
          </button>
        ))}
      </nav>
      <div style={{padding:"12px 18px",borderTop:"1px solid rgba(201,168,76,.12)"}}>
        <button onClick={onLogout} className="ibtn" style={{width:"100%",background:"rgba(139,26,0,.2)",border:"1px solid rgba(139,26,0,.3)",color:"#ff7b7b",padding:"8px",borderRadius:8,fontSize:12,fontFamily:SAN,cursor:"pointer"}}>Déconnexion</button>
      </div>
    </aside>
  );
}

/* ══ MAIN ═════════════════════════════════════════════════════════════════ */
export default function Admin(){
  useEffect(()=>{injectCSS();},[]);

  const [authed,setAuthed]=useState(false);
  const [lEmail,setLEmail]=useState("");
  const [lPass,setLPass]=useState("");
  const [lErr,setLErr]=useState("");

  const [page,setPage]=useState("dashboard");
  const [products,setProducts]=useState(INIT_P);
  const [artisans,setArtisans]=useState(INIT_A);
  const [orders,setOrders]=useState(INIT_O);
  const [reqs,setReqs]=useState(INIT_REQ);
  const [emailLog,setEmailLog]=useState(INIT_EMAIL_LOG);
  const [toast,setToast]=useState("");
  const [modal,setModal]=useState(null);
  const [confirm,setConfirm]=useState(null);
  const [emailPreview,setEmailPreview]=useState(null);
  const [showWA,setShowWA]=useState(false);
  const [showComposer,setShowComposer]=useState(false);
  const [commTab,setCommTab]=useState("log");
  const [commFilter,setCommFilter]=useState("all");

  const [catF,setCatF]=useState("all");
  const [qP,setQP]=useState("");
  const [qA,setQA]=useState("");
  const [artTab,setArtTab]=useState("actifs");

  useEffect(()=>{
    loadAllPhotos(INIT_P).then(pm=>{
      if(Object.keys(pm).length>0) setProducts(prev=>prev.map(p=>pm[p.id]?{...p,photos:pm[p.id]}:p));
    });
  },[]);

  const say=m=>setToast(m);

  /* Email log helper + vrai envoi Brevo */
  const logEmail=async entry=>{
    setEmailLog(prev=>[{id:Date.now(),...entry,date:new Date().toLocaleString("fr-CA"),status:"sending"},...prev]);
    try {
      const result = await sendEmail(entry.type||"custom", entry.to, entry.client, {
        client: entry.client,
        orderId: entry.orderId,
        newStatus: entry.newStatus,
        subject: entry.subject,
        message: entry.body,
        items: entry.items,
        total: entry.total,
      });
      setEmailLog(prev=>prev.map(e=>e.id===prev[0]?.id?{...e,status:result.success?"sent":"error"}:e));
      if(result.success) say(`✉ Email envoyé à ${entry.to}`);
      else say(`⚠ Erreur envoi: ${result.error}`);
    } catch(err) {
      say(`⚠ Erreur: ${err.message}`);
    }
  };

  /* Product ops */
  const saveProduct=async p=>{
    await savePhotos(p.id,p.photos||[]);
    setProducts(prev=>{const ex=prev.find(x=>x.id===p.id);return ex?prev.map(x=>x.id===p.id?p:x):[...prev,p];});
    say("Produit sauvegardé ✓");setModal(null);
  };
  const delProduct=id=>{setProducts(p=>p.filter(x=>x.id!==id));say("Produit supprimé");setConfirm(null);};

  /* Artisan ops */
  const saveArtisan=a=>{
    const isNew=!artisans.find(x=>x.id===a.id);
    setArtisans(prev=>{const ex=prev.find(x=>x.id===a.id);return ex?prev.map(x=>x.id===a.id?a:x):[...prev,a];});
    if(isNew&&a.email){
      logEmail({type:"bienvenue",to:a.email,client:a.name,subject:`✦ Bienvenue chez BADAOUR, ${a.name.split(" ")[0]} !`,orderId:null});
      say("Artisan ajouté + email bienvenue envoyé ✓");
    } else say("Artisan modifié ✓");
    setModal(null);
  };
  const delArtisan=id=>{setArtisans(p=>p.filter(x=>x.id!==id));say("Artisan supprimé");setConfirm(null);};

  /* Order ops */
  const advanceOrder=id=>{
    const o=orders.find(x=>x.id===id);
    if(!o)return;
    const ci=STATUS_FLOW.indexOf(o.status);
    if(ci>=STATUS_FLOW.length-1)return;
    const nextStatus=STATUS_FLOW[ci+1];
    setOrders(p=>p.map(x=>x.id===id?{...x,status:nextStatus}:x));
    // Auto-log notification email
    logEmail({
      type:"suivi",
      to:o.email,
      client:o.client,
      subject:`⊡ BADAOUR — ${o.id} : ${STATUS_LABELS[nextStatus]}`,
      orderId:o.id,
      statusKey:nextStatus,
      newStatus:STATUS_LABELS[nextStatus],
    });
    say(`Statut → ${STATUS_LABELS[nextStatus]} + notification client ✓`);
  };

  /* Partner ops */
  const handleReq=(id,action)=>{
    setReqs(p=>p.map(r=>r.id===id?{...r,status:action}:r));
    if(action==="approved"){
      const r=reqs.find(x=>x.id===id);
      if(r){
        const newArtisan={id:Date.now(),name:r.name,metier:r.metier,ville:"",pays:r.pays,flag:"✦",exp:"",email:r.email,phone:r.phone,bio:r.msg,status:"actif",photo:null,produits:0};
        setArtisans(p=>[...p,newArtisan]);
        logEmail({type:"bienvenue",to:r.email,client:r.name,subject:`✦ Bienvenue chez BADAOUR, ${r.name.split(" ")[0]} — Partenariat approuvé !`,orderId:null});
        say("Partenaire approuvé + email bienvenue ✓");
      }
    } else say("Demande refusée");
  };

  const pendingR=reqs.filter(r=>r.status==="pending").length;
  const pendingO=orders.filter(o=>o.status==="preparation").length;
  const revenue=orders.reduce((a,o)=>a+o.total,0);
  const stockVal=products.reduce((a,p)=>a+p.price*p.stock,0);
  const artisanNames=artisans.map(a=>a.name);
  const clientList=orders.reduce((acc,o)=>{const ex=acc.find(c=>c.email===o.email);if(ex){ex.total+=o.total;ex.cmds++;}else acc.push({name:o.client,email:o.email,total:o.total,cmds:1,last:o.date});return acc;},[]);
  const newEmailsCount=0; // could track unread

  /* ── LOGIN ── */
  if(!authed) return(
    <div style={{minHeight:"100vh",background:"#0C0A08",display:"flex",alignItems:"center",justifyContent:"center",padding:20,position:"relative",overflow:"hidden"}}>
      {/* Background particles simulation */}
      {Array.from({length:55}).map((_,i)=>(<div key={i} style={{position:"absolute",left:`${Math.floor((i*37)%100)}%`,top:`${Math.floor((i*53)%100)}%`,width:i%5===0?3:i%3===0?2:1.5,height:i%5===0?3:i%3===0?2:1.5,borderRadius:"50%",background:i%4===0?`rgba(201,168,76,${.12+i*.005})`:`rgba(255,255,255,${.04+i*.003})`,pointerEvents:"none",animation:`twinkle ${2.5+(i%4)*.6}s ease-in-out infinite`,animationDelay:`${(i*.18)%3}s`}}/>))}
      {/* Floating emojis faint */}
      {["◈","✦","✦","✦","✨"].map((e,i)=>(<div key={e} style={{position:"absolute",left:`${[8,76,88,15,65][i]}%`,top:`${[15,10,55,72,40][i]}%`,fontSize:[44,36,40,38,30][i],filter:"brightness(.18) sepia(.3)",animation:`floatA ${4+i*.7}s ease-in-out infinite`,animationDelay:`${i*.8}s`,pointerEvents:"none"}}>{e}</div>))}

      <div style={{position:"relative",zIndex:2,width:"100%",maxWidth:420,animation:"fadeUp .5s ease both"}}>
        {/* Logo */}
        <div style={{textAlign:"center",marginBottom:36}}>
          <div style={{fontSize:36,fontWeight:900,color:G,letterSpacing:6,fontFamily:S,textShadow:`0 0 40px rgba(201,168,76,.3)`}}>BADAOUR</div>
          <div style={{fontSize:9,color:`${G}60`,letterSpacing:5,marginTop:5,fontFamily:SAN,textTransform:"uppercase"}}>Administration</div>
        </div>
        {/* Card */}
        <div style={{background:"rgba(255,255,255,.97)",borderRadius:18,padding:40,boxShadow:"0 24px 60px rgba(0,0,0,.4)",border:"1px solid rgba(201,168,76,.15)"}}>
          <h2 style={{fontSize:22,fontWeight:700,color:DARK,fontFamily:S,textAlign:"center",marginBottom:6}}>Connexion</h2>
          <p style={{textAlign:"center",fontSize:12,color:MUT,fontFamily:SAN,marginBottom:28}}>Espace réservé aux administrateurs</p>
          <Field label="Email"><Inp type="email" value={lEmail} onChange={e=>setLEmail(e.target.value)} placeholder="admin@badaour.com"/></Field>
          <Field label="Mot de passe"><Inp type="password" value={lPass} onChange={e=>setLPass(e.target.value)} placeholder="••••••••"/></Field>
          {lErr&&<div style={{color:RED,fontSize:12,marginBottom:12,fontFamily:SAN,textAlign:"center",background:"rgba(139,26,0,.06)",padding:"8px",borderRadius:8}}>{lErr}</div>}
          <Btn gold full style={{marginTop:8,padding:"14px",fontSize:14,letterSpacing:1}} onClick={()=>{
            if(lEmail==="admin@badaour.com"&&lPass==="badaour2025"){setAuthed(true);setLErr("");}
            else setLErr("Email ou mot de passe incorrect");
          }}>SE CONNECTER</Btn>
          <p style={{textAlign:"center",marginTop:16,fontSize:10,color:MUT,fontFamily:SAN,letterSpacing:.5}}>admin@badaour.com · badaour2025</p>
        </div>
      </div>
      <Toast msg={toast} onClose={()=>setToast("")}/>
    </div>
  );

  /* ── PAGE DASHBOARD ── */
  const PageDashboard=()=>(
    <div className="page">
      <div style={{marginBottom:24}}>
        <h1 style={{fontSize:28,fontWeight:700,color:DARK,fontFamily:S,letterSpacing:"-.3px"}}>Tableau de bord</h1>
        <p style={{color:MUT,fontSize:13,fontFamily:SAN}}>{new Date().toLocaleDateString("fr-CA",{weekday:"long",year:"numeric",month:"long",day:"numeric"})}</p>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:14,marginBottom:24}}>
        <KPI icon="◆" label="Chiffre d'affaires" value={`${revenue.toFixed(0)} $`} sub={`${orders.length} commandes`} color={G}/>
        <KPI icon="⊡" label="Produits actifs" value={products.length} sub={`${products.filter(p=>p.stock<5).length} stock faible`} color={RED}/>
        <KPI icon="✉" label="Emails envoyés" value={emailLog.length} sub={`${emailLog.filter(e=>e.type==="commande").length} confirmations`} color="#1A5276"/>
        <KPI icon="◈" label="Valeur en stock" value={`${(stockVal/1000).toFixed(1)}k $`} sub="Total inventaire" color={GREEN}/>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1.6fr 1fr",gap:16,marginBottom:16}}>
        <div style={{background:"white",borderRadius:14,padding:22,boxShadow:"0 2px 16px rgba(0,0,0,.06)",border:`1px solid ${BDR}`}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
            <h3 style={{fontSize:15,fontWeight:700,color:DARK,fontFamily:S}}>Commandes récentes</h3>
            <button onClick={()=>setPage("orders")} className="ibtn" style={{background:"none",border:"none",color:G,fontSize:12,fontFamily:SAN,cursor:"pointer"}}>Voir tout →</button>
          </div>
          {orders.slice(0,5).map(o=>(
            <div key={o.id} className="row" style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"9px 0",borderBottom:`1px solid ${BDR}`,gap:8}}>
              <div>
                <div style={{fontSize:13,fontWeight:600,color:DARK,fontFamily:SAN}}>{o.client}</div>
                <div style={{fontSize:11,color:MUT,fontFamily:SAN}}>{o.id} · {o.date}</div>
              </div>
              <div style={{display:"flex",alignItems:"center",gap:8,flexShrink:0}}>
                <Badge text={o.status}/>
                <span style={{fontWeight:700,color:DARK,fontSize:13,fontFamily:SAN}}>{o.total.toFixed(0)} $</span>
              </div>
            </div>
          ))}
        </div>
        <div style={{background:"white",borderRadius:14,padding:22,boxShadow:"0 2px 16px rgba(0,0,0,.06)",border:`1px solid ${BDR}`}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
            <h3 style={{fontSize:15,fontWeight:700,color:DARK,fontFamily:S}}>✉ Derniers emails</h3>
            <button onClick={()=>setPage("communications")} className="ibtn" style={{background:"none",border:"none",color:G,fontSize:12,fontFamily:SAN,cursor:"pointer"}}>Voir tout →</button>
          </div>
          {emailLog.slice(0,6).map(e=>(
            <div key={e.id} onClick={()=>setEmailPreview(e)} className="row" style={{cursor:"pointer",display:"flex",gap:8,alignItems:"flex-start",padding:"8px 0",borderBottom:`1px solid ${BDR}`}}>
              <div style={{flexShrink:0,marginTop:2}}>
                <Badge text={e.type}/>
              </div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontSize:12,fontWeight:600,color:DARK,fontFamily:SAN,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{e.client}</div>
                <div style={{fontSize:10,color:MUT,fontFamily:SAN}}>{e.date}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  /* ── PAGE COMMUNICATIONS ── */
  const filteredLog=emailLog.filter(e=>commFilter==="all"||e.type===commFilter);
  const PageCommunications=()=>(
    <div className="page">
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20,flexWrap:"wrap",gap:12}}>
        <div>
          <h1 style={{fontSize:26,fontWeight:700,color:DARK,fontFamily:S}}>Communications</h1>
          <p style={{color:MUT,fontSize:12,fontFamily:SAN}}>{emailLog.length} emails · Système EmailJS / Brevo</p>
        </div>
        <div style={{display:"flex",gap:8}}>
          <Btn outline onClick={()=>setShowWA(true)}>✆ WhatsApp artisan</Btn>
          <Btn gold onClick={()=>setShowComposer(true)}>✉ Composer email</Btn>
        </div>
      </div>

      {/* KPIs comm */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:20}}>
        {[
          {icon:"⊡",label:"Confirmations",value:emailLog.filter(e=>e.type==="commande").length,color:"#1A3A6B"},
          {icon:"✦",label:"Bienvenus",    value:emailLog.filter(e=>e.type==="bienvenue").length,color:"#6A0572"},
          {icon:"◆",label:"Suivis",       value:emailLog.filter(e=>e.type==="suivi").length,color:"#8B4513"},
          {icon:"✉",label:"Personnalisés",value:emailLog.filter(e=>e.type==="custom").length,color:MUT},
        ].map(k=><KPI key={k.label} icon={k.icon} label={k.label} value={k.value} color={k.color}/>)}
      </div>

      {/* Tabs */}
      <div style={{display:"flex",gap:8,marginBottom:16,flexWrap:"wrap"}}>
        {[["all","Tous"],["commande","⊡ Commande"],["bienvenue","✦ Bienvenue"],["suivi","◆ Suivi"],["custom","✉ Custom"]].map(([k,l])=>(
          <button key={k} onClick={()=>setCommFilter(k)} className="ibtn"
            style={{padding:"7px 16px",borderRadius:50,border:`1px solid ${commFilter===k?G:BDR}`,background:commFilter===k?G:"white",color:commFilter===k?DARK:MUT,fontSize:12,fontFamily:SAN,fontWeight:commFilter===k?700:400,cursor:"pointer"}}>
            {l}
          </button>
        ))}
      </div>

      {/* Email log table */}
      <div style={{background:"white",borderRadius:12,overflow:"hidden",boxShadow:"0 2px 12px rgba(0,0,0,.06)"}}>
        <div style={{overflowX:"auto"}}>
          <table style={{width:"100%",borderCollapse:"collapse",fontSize:13,fontFamily:SAN}}>
            <thead>
              <tr style={{background:BG}}>
                {["Type","Destinataire","Sujet","Date","Statut","Action"].map(h=>(
                  <th key={h} style={{padding:"11px 14px",fontSize:10,fontWeight:700,color:MUT,textTransform:"uppercase",letterSpacing:.5,borderBottom:`2px solid ${BDR}`,textAlign:"left"}}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredLog.map(e=>(
                <tr key={e.id} className="row" style={{borderBottom:`1px solid ${BDR}`}}>
                  <td style={{padding:"11px 14px"}}><Badge text={e.type}/></td>
                  <td style={{padding:"11px 14px"}}>
                    <div style={{fontWeight:600,color:DARK}}>{e.client}</div>
                    <div style={{fontSize:11,color:MUT}}>{e.to}</div>
                  </td>
                  <td style={{padding:"11px 14px",maxWidth:260}}>
                    <div style={{fontSize:12,color:DARK,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis",maxWidth:240}}>{e.subject}</div>
                    {e.orderId&&<div style={{fontSize:10,color:MUT}}>{e.orderId}</div>}
                  </td>
                  <td style={{padding:"11px 14px",color:MUT,fontSize:11,whiteSpace:"nowrap"}}>{e.date}</td>
                  <td style={{padding:"11px 14px"}}><Badge text="sent"/></td>
                  <td style={{padding:"11px 14px"}}>
                    <Btn sm outline onClick={()=>setEmailPreview(e)}>◈ Aperçu</Btn>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!filteredLog.length&&<div style={{padding:40,textAlign:"center",color:MUT,fontFamily:SAN}}>Aucun email dans ce filtre.</div>}
      </div>

      {/* Config note */}
      <div style={{background:"rgba(26,58,107,.06)",border:"1px solid rgba(26,58,107,.2)",borderRadius:12,padding:"16px 20px",marginTop:16}}>
        <div style={{fontSize:13,fontWeight:700,color:"#1A3A6B",marginBottom:8,fontFamily:SAN}}>◆ Configuration EmailJS / Brevo</div>
        <div style={{fontSize:11,color:MUT,fontFamily:SAN,lineHeight:1.8}}>
          Pour activer l'envoi réel · Remplacez dans le code :<br/>
          <code style={{background:"#eee",padding:"2px 6px",borderRadius:4}}>EMAILJS_PUBLIC_KEY = "votre_clé"</code> · 
          <code style={{background:"#eee",padding:"2px 6px",borderRadius:4,marginLeft:8}}>SERVICE_ID = "service_739boyk"</code><br/>
          300 emails/jour gratuits · Voir guide BADAOUR_EMAIL_TEMPLATES
        </div>
      </div>
    </div>
  );

  /* ── PAGE PRODUITS ── */
  const filtP=products.filter(p=>{if(catF!=="all"&&p.cat!==catF)return false;if(qP&&!p.name.toLowerCase().includes(qP.toLowerCase()))return false;return true;});
  const PageProducts=()=>(
    <div className="page">
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18,flexWrap:"wrap",gap:10}}>
        <h1 style={{fontSize:26,fontWeight:700,color:DARK,fontFamily:S}}>Produits ({products.length})</h1>
        <Btn gold onClick={()=>setModal({t:"addP"})}>+ Ajouter un produit</Btn>
      </div>
      <div style={{display:"flex",gap:8,marginBottom:18,flexWrap:"wrap",alignItems:"center"}}>
        <input value={qP} onChange={e=>setQP(e.target.value)} placeholder="Rechercher…" style={{padding:"8px 14px",border:`1.5px solid ${BDR}`,borderRadius:50,fontSize:12,outline:"none",background:"white",fontFamily:SAN}}/>
        {["all",...CATS].map(c=>(
          <button key={c} onClick={()=>setCatF(c)} className="ibtn" style={{padding:"7px 16px",borderRadius:50,border:`1px solid ${catF===c?G:BDR}`,background:catF===c?G:"white",color:catF===c?DARK:MUT,fontSize:12,fontFamily:SAN,fontWeight:catF===c?700:400,cursor:"pointer"}}>
            {c==="all"?"Tous":c.charAt(0).toUpperCase()+c.slice(1)}
          </button>
        ))}
      </div>
      <div style={{background:"rgba(212,175,55,.1)",border:"1px solid rgba(212,175,55,.3)",borderRadius:10,padding:"10px 16px",marginBottom:18,fontSize:12,color:"#7A5C1E",fontFamily:SAN}}>
        ◆ Photos ajoutées ici → automatiquement visibles dans la boutique · Max {MAX_PHOTOS} photos par produit
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))",gap:16}}>
        {filtP.map(p=>(
          <div key={p.id} style={{background:"white",borderRadius:12,overflow:"hidden",border:`1px solid ${BDR}`,boxShadow:"0 2px 10px rgba(0,0,0,.05)"}}>
            <div style={{height:140,background:BG,display:"flex",alignItems:"center",justifyContent:"center",position:"relative",overflow:"hidden"}}>
              {p.photos&&p.photos.length>0?<img src={p.photos[0]} alt={p.name} style={{width:"100%",height:"100%",objectFit:"cover"}}/>:<span style={{fontSize:52}}>{p.emoji}</span>}
              <div style={{position:"absolute",top:8,right:8,background:"rgba(0,0,0,.7)",color:"white",padding:"3px 9px",borderRadius:20,fontSize:10,fontFamily:SAN,fontWeight:600}}>◆ {p.photos?.length||0}/{MAX_PHOTOS}</div>
              <div style={{position:"absolute",top:8,left:8}}><Badge text={p.tag}/></div>
            </div>
            <div style={{padding:"13px 15px"}}>
              <div style={{fontSize:10,color:MUT,textTransform:"uppercase",letterSpacing:1,fontWeight:700,fontFamily:SAN,marginBottom:2}}>{p.cat}</div>
              <div style={{fontSize:14,fontWeight:700,color:DARK,fontFamily:S,lineHeight:1.25,marginBottom:3}}>{p.name}</div>
              <div style={{fontSize:11,color:MUT,marginBottom:7,fontFamily:SAN}}>✦ {p.artisan}</div>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
                <span style={{fontSize:17,fontWeight:700,color:DARK,fontFamily:S}}>{p.price}<span style={{fontSize:11,color:MUT}}> $CA</span></span>
                <div style={{display:"flex",gap:8,fontSize:11,fontFamily:SAN}}>
                  <span style={{color:p.stock<5?RED:GREEN,fontWeight:700}}>⊡ {p.stock}</span>
                  <span style={{color:MUT}}>✅ {p.sold}</span>
                </div>
              </div>
              <div style={{display:"flex",gap:7}}>
                <Btn sm outline style={{flex:1}} onClick={()=>setModal({t:"editP",data:{...p,photos:p.photos||[]}})}>✏️ Modifier / Photos</Btn>
                <Btn sm danger onClick={()=>setConfirm({msg:`Supprimer "${p.name}" ?`,onOk:()=>delProduct(p.id)})}>✕</Btn>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  /* ── PAGE ARTISANS ── */
  const filtA=artisans.filter(a=>{if(qA&&!a.name.toLowerCase().includes(qA.toLowerCase()))return false;if(artTab==="actifs")return a.status==="actif";if(artTab==="inactifs")return a.status==="inactif";return true;});
  const PageArtisans=()=>(
    <div className="page">
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18,flexWrap:"wrap",gap:10}}>
        <h1 style={{fontSize:26,fontWeight:700,color:DARK,fontFamily:S}}>Artisans ({artisans.length})</h1>
        <div style={{display:"flex",gap:8}}>
          <Btn outline onClick={()=>setShowWA(true)}>✆ WhatsApp</Btn>
          <Btn gold onClick={()=>setModal({t:"addA"})}>+ Ajouter</Btn>
        </div>
      </div>
      <div style={{display:"flex",gap:8,marginBottom:18,flexWrap:"wrap",alignItems:"center"}}>
        {[["actifs","✅ Actifs"],["inactifs","⏸ Inactifs"],["demandes","✉ Demandes"]].map(([k,l])=>(
          <button key={k} onClick={()=>setArtTab(k)} className="ibtn" style={{padding:"8px 18px",borderRadius:50,border:`1px solid ${artTab===k?G:BDR}`,background:artTab===k?G:"white",color:artTab===k?DARK:MUT,fontSize:12,fontFamily:SAN,fontWeight:artTab===k?700:400,cursor:"pointer",display:"flex",gap:6,alignItems:"center"}}>
            {l}{k==="demandes"&&pendingR>0&&<span style={{background:RED,color:"white",borderRadius:10,fontSize:10,fontWeight:700,padding:"0 6px"}}>{pendingR}</span>}
          </button>
        ))}
        {artTab!=="demandes"&&<input value={qA} onChange={e=>setQA(e.target.value)} placeholder="Rechercher…" style={{padding:"8px 14px",border:`1.5px solid ${BDR}`,borderRadius:50,fontSize:12,outline:"none",background:"white",fontFamily:SAN}}/>}
      </div>
      {artTab!=="demandes"?(
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(290px,1fr))",gap:16}}>
          {filtA.map(a=>(
            <div key={a.id} style={{background:"white",borderRadius:12,padding:18,border:`1px solid ${BDR}`,boxShadow:"0 2px 10px rgba(0,0,0,.05)",display:"flex",gap:14,alignItems:"flex-start"}}>
              <div style={{position:"relative",flexShrink:0}}>
                <div style={{width:62,height:62,borderRadius:"50%",overflow:"hidden",background:"#EEE4D0",display:"flex",alignItems:"center",justifyContent:"center",border:`2px solid ${BDR}`}}>
                  {a.photo?<img src={a.photo} alt={a.name} style={{width:"100%",height:"100%",objectFit:"cover"}}/>:<span style={{fontSize:24}}>◉</span>}
                </div>
                <div style={{position:"absolute",bottom:-4,right:-4,background:"white",borderRadius:"50%",width:20,height:20,display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,border:`1.5px solid ${BDR}`}}>{a.flag}</div>
              </div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontSize:10,color:MUT,textTransform:"uppercase",letterSpacing:1,fontWeight:700,fontFamily:SAN,marginBottom:2}}>{a.metier}</div>
                <div style={{fontSize:15,fontWeight:700,color:DARK,fontFamily:S,marginBottom:2}}>{a.name}</div>
                <div style={{fontSize:11,color:MUT,marginBottom:3,fontFamily:SAN}}>◆ {a.ville}{a.ville&&", "}{a.pays} · ★ {a.exp}</div>
                <div style={{fontSize:11,color:MUT,marginBottom:8,fontFamily:SAN}}>✉ {a.email}</div>
                <div style={{display:"flex",gap:6,flexWrap:"wrap",alignItems:"center"}}>
                  <Badge text={a.status}/>
                  <Btn sm outline onClick={()=>setModal({t:"editA",data:a})}>✏️ Modifier</Btn>
                  <Btn sm danger onClick={()=>setConfirm({msg:`Supprimer "${a.name}" ?`,onOk:()=>delArtisan(a.id)})}>✕</Btn>
                </div>
              </div>
            </div>
          ))}
        </div>
      ):(
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          {reqs.map(r=>(
            <div key={r.id} style={{background:"white",borderRadius:12,padding:20,border:`1px solid ${BDR}`,boxShadow:"0 2px 10px rgba(0,0,0,.05)"}}>
              <div style={{display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:12}}>
                <div>
                  <div style={{fontSize:16,fontWeight:700,color:DARK,fontFamily:S,marginBottom:2}}>{r.name}</div>
                  <div style={{fontSize:12,color:MUT,fontFamily:SAN,marginBottom:4}}>{r.metier} · {r.pays} · {r.date}</div>
                  <div style={{fontSize:12,color:MUT,fontFamily:SAN,marginBottom:10}}>✉ {r.email} · ✆ {r.phone}</div>
                  <div style={{fontSize:13,color:DARK,fontFamily:SAN,lineHeight:1.65,maxWidth:500}}>{r.msg}</div>
                </div>
                <div style={{display:"flex",flexDirection:"column",gap:8,alignItems:"flex-end"}}>
                  <Badge text={r.status}/>
                  {r.status==="pending"&&<div style={{display:"flex",gap:8}}><Btn sm gold onClick={()=>handleReq(r.id,"approved")}>✅ Approuver</Btn><Btn sm danger onClick={()=>handleReq(r.id,"rejected")}>❌ Refuser</Btn></div>}
                </div>
              </div>
            </div>
          ))}
          {!reqs.length&&<p style={{color:MUT,textAlign:"center",padding:40,fontFamily:SAN}}>Aucune demande.</p>}
        </div>
      )}
    </div>
  );

  /* ── PAGE COMMANDES ── */
  const PageOrders=()=>(
    <div className="page">
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20,flexWrap:"wrap",gap:10}}>
        <h1 style={{fontSize:26,fontWeight:700,color:DARK,fontFamily:S}}>Commandes ({orders.length})</h1>
        <div style={{background:"rgba(26,58,107,.08)",border:"1px solid rgba(26,58,107,.2)",borderRadius:8,padding:"8px 14px",fontSize:11,color:"#1A3A6B",fontFamily:SAN}}>
          ◆ Notification email automatique à chaque avancement de statut
        </div>
      </div>
      <div style={{background:"white",borderRadius:12,overflow:"hidden",boxShadow:"0 2px 12px rgba(0,0,0,.06)"}}>
        <div style={{overflowX:"auto"}}>
          <table style={{width:"100%",borderCollapse:"collapse",fontSize:13,fontFamily:SAN}}>
            <thead>
              <tr style={{background:BG}}>
                {["Numéro","Date","Client","Total","Paiement","Statut","Actions"].map(h=>(
                  <th key={h} style={{padding:"11px 14px",fontSize:10,fontWeight:700,color:MUT,textTransform:"uppercase",letterSpacing:.5,borderBottom:`2px solid ${BDR}`,textAlign:"left"}}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {orders.map(o=>(
                <tr key={o.id} className="row" style={{borderBottom:`1px solid ${BDR}`}}>
                  <td style={{padding:"12px 14px",fontWeight:700,color:DARK}}>{o.id}</td>
                  <td style={{padding:"12px 14px",color:MUT}}>{o.date}</td>
                  <td style={{padding:"12px 14px"}}>
                    <div style={{fontWeight:600,color:DARK}}>{o.client}</div>
                    <div style={{fontSize:11,color:MUT}}>{o.email}</div>
                  </td>
                  <td style={{padding:"12px 14px",fontWeight:700,color:DARK}}>{o.total.toFixed(2)} $</td>
                  <td style={{padding:"12px 14px",color:MUT}}>{o.payMethod}</td>
                  <td style={{padding:"12px 14px"}}><Badge text={o.status}/></td>
                  <td style={{padding:"12px 14px"}}>
                    <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
                      {o.status!=="delivered"&&<Btn sm gold onClick={()=>advanceOrder(o.id)}>Avancer →</Btn>}
                      <Btn sm outline onClick={()=>{
                        const lastEmail=emailLog.find(e=>e.orderId===o.id&&e.type==="suivi")||emailLog.find(e=>e.orderId===o.id);
                        if(lastEmail) setEmailPreview(lastEmail);
                        else setToast("Aucun email pour cette commande");
                      }}>✉</Btn>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  /* ── PAGE CLIENTS ── */
  const PageClients=()=>(
    <div className="page">
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20,flexWrap:"wrap",gap:10}}>
        <h1 style={{fontSize:26,fontWeight:700,color:DARK,fontFamily:S}}>Clients ({clientList.length})</h1>
        <Btn outline onClick={()=>setShowComposer(true)}>✉ Envoyer un email</Btn>
      </div>
      <div style={{background:"white",borderRadius:12,overflow:"hidden",boxShadow:"0 2px 12px rgba(0,0,0,.06)"}}>
        <table style={{width:"100%",borderCollapse:"collapse",fontSize:13,fontFamily:SAN}}>
          <thead>
            <tr style={{background:BG}}>
              {["Client","Email","Commandes","Total","Dernière commande","Action"].map(h=>(
                <th key={h} style={{padding:"11px 14px",fontSize:10,fontWeight:700,color:MUT,textTransform:"uppercase",letterSpacing:.5,borderBottom:`2px solid ${BDR}`,textAlign:"left"}}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {clientList.map(c=>(
              <tr key={c.email} className="row" style={{borderBottom:`1px solid ${BDR}`}}>
                <td style={{padding:"12px 14px",fontWeight:600,color:DARK}}>{c.name}</td>
                <td style={{padding:"12px 14px",color:MUT}}>{c.email}</td>
                <td style={{padding:"12px 14px",textAlign:"center",fontWeight:700}}>{c.cmds}</td>
                <td style={{padding:"12px 14px",fontWeight:700,color:GREEN}}>{c.total.toFixed(2)} $</td>
                <td style={{padding:"12px 14px",color:MUT}}>{c.last}</td>
                <td style={{padding:"12px 14px"}}>
                  <Btn sm outline onClick={()=>{setShowComposer(true);}}>✉ Écrire</Btn>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  /* ── PAGE PARAMÈTRES ── */
  const PageSettings=()=>(
    <div className="page">
      <h1 style={{fontSize:26,fontWeight:700,color:DARK,fontFamily:S,marginBottom:22}}>Paramètres</h1>
      {[
        {title:"Informations générales",fields:[["Nom de la boutique","BADAOUR"],["Email principal",EMAIL],["Téléphone",PHONE],["Ville","Montréal, Québec, Canada"]]},
        {title:"Livraison",fields:[["Délai estimé","14 à 21 jours"],["Frais fixes ($CA)","18"],["Pays desservis","Canada"]]},
        {title:"Paiement",fields:[["Email Interac",EMAIL],["Email PayPal","paypal@badaour.com"]]},
        {title:"Notifications EmailJS",fields:[["Public Key","YOUR_PUBLIC_KEY"],["Service ID","service_739boyk"],["Template commande","template_commande"],["Template bienvenue","template_bienvenue"],["Template suivi","template_suivi"]]},
      ].map(sec=>(
        <div key={sec.title} style={{background:"white",borderRadius:12,padding:"20px 24px",marginBottom:16,boxShadow:"0 2px 10px rgba(0,0,0,.05)",border:`1px solid ${BDR}`}}>
          <h3 style={{fontSize:15,fontWeight:700,color:DARK,fontFamily:S,marginBottom:16,paddingBottom:10,borderBottom:`1px solid ${BDR}`}}>{sec.title}</h3>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            {sec.fields.map(([l,v])=>(<Field key={l} label={l}><Inp defaultValue={v}/></Field>))}
          </div>
          <Btn gold sm style={{marginTop:10}} onClick={()=>say("Paramètres sauvegardés ✓")}>Sauvegarder</Btn>
        </div>
      ))}
    </div>
  );

  const renderPage=()=>{
    if(page==="dashboard")     return <PageDashboard/>;
    if(page==="orders")        return <PageOrders/>;
    if(page==="products")      return <PageProducts/>;
    if(page==="artisans")      return <PageArtisans/>;
    if(page==="clients")       return <PageClients/>;
    if(page==="communications")return <PageCommunications/>;
    if(page==="settings")      return <PageSettings/>;
    return <PageDashboard/>;
  };

  return(
    <div style={{minHeight:"100vh",background:BG,display:"flex",fontFamily:SAN}}>
      <Sidebar page={page} setPage={setPage} onLogout={()=>setAuthed(false)} pendingR={pendingR} pendingO={pendingO} newEmails={newEmailsCount}/>
      <div style={{flex:1,display:"flex",flexDirection:"column",minWidth:0}}>
        <div style={{background:"white",borderBottom:`1px solid ${BDR}`,padding:"0 28px",display:"flex",alignItems:"center",justifyContent:"space-between",height:58,position:"sticky",top:0,zIndex:100,flexShrink:0,boxShadow:"0 1px 8px rgba(0,0,0,.04)"}}>
          <div style={{fontSize:11,color:MUT,fontFamily:SAN}}>✆ {PHONE} &nbsp;·&nbsp; ✉ {EMAIL}</div>
          <div style={{display:"flex",gap:8,alignItems:"center"}}>
            <button onClick={()=>{setPage("communications");}} className="ibtn"
              style={{background:"rgba(26,58,107,.08)",border:"1px solid rgba(26,58,107,.2)",borderRadius:50,padding:"5px 14px",fontSize:11,color:"#1A3A6B",fontWeight:600,fontFamily:SAN,cursor:"pointer"}}>
              ✉ {emailLog.length} emails
            </button>
            <div style={{background:`${G}1A`,border:`1px solid ${G}44`,borderRadius:50,padding:"5px 14px",fontSize:12,color:DARK,fontWeight:600,fontFamily:SAN}}>⊠️ Administrateur</div>
          </div>
        </div>
        <main style={{padding:"26px 30px",flex:1,overflowY:"auto",background:"#F5F0E8"}}>{renderPage()}</main>
      </div>

      {/* Modals */}
      {modal?.t==="addP"&&<Modal title="Ajouter un produit" onClose={()=>setModal(null)} wide><ProductForm artisanNames={artisanNames} onSave={saveProduct} onClose={()=>setModal(null)}/></Modal>}
      {modal?.t==="editP"&&<Modal title="Modifier / Gérer les photos" onClose={()=>setModal(null)} wide><ProductForm init={modal.data} artisanNames={artisanNames} onSave={saveProduct} onClose={()=>setModal(null)}/></Modal>}
      {modal?.t==="addA"&&<Modal title="Ajouter un artisan" onClose={()=>setModal(null)}><ArtisanForm onSave={saveArtisan} onClose={()=>setModal(null)}/></Modal>}
      {modal?.t==="editA"&&<Modal title="Modifier l'artisan" onClose={()=>setModal(null)}><ArtisanForm init={modal.data} onSave={saveArtisan} onClose={()=>setModal(null)}/></Modal>}
      {confirm&&<Confirm msg={confirm.msg} onOk={confirm.onOk} onCancel={()=>setConfirm(null)}/>}
      {emailPreview&&<EmailPreview email={emailPreview} onClose={()=>setEmailPreview(null)}/>}
      {showWA&&<WAGenerator artisans={artisans} orders={orders} onClose={()=>setShowWA(false)}/>}
      {showComposer&&<AIComposer clients={clientList} orders={orders} onSend={e=>{logEmail(e);setShowComposer(false);}} onClose={()=>setShowComposer(false)}/>}
      <Toast msg={toast} onClose={()=>setToast("")}/>
    </div>
  );
}
