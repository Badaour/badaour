import Boutique from "./Boutique";
import Admin from "./Admin";

export default function App() {
  const isAdmin = window.location.pathname.startsWith("/admin");
  return isAdmin ? <Admin /> : <Boutique />;
}
