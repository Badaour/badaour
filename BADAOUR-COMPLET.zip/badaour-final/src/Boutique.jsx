import { useState, useEffect, useRef, useCallback, createContext, useContext } from "react";
import { sendOrderConfirmation, sendWelcomeEmail, sendArtisanConfirmation, openWhatsApp } from "./communication.js";

/* ═══════════════════════════════════════════════════════════════════════════
   DESIGN TOKENS
═══════════════════════════════════════════════════════════════════════════ */
const G    = "#C9A84C";
const DARK = "#1A1714";
const BG   = "#FDFCF9";
const BG2  = "#F5F0E8";
const HERO = "#0C0A08";
const TEXT = "#1A1714";
const MUT  = "#8A7E6E";
const BORD = "#E8E2D8";
const RED  = "#8B1A00";
const GREEN= "#1E6E3D";
const PHONE= "438-988-6682";
const EMAIL= "service@badaour.com";
const S    = "'Playfair Display', Georgia, serif";
const SAN  = "'DM Sans', sans-serif";

const CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,900;1,700;1,900&family=DM+Sans:wght@300;400;500;600;700&display=swap');
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
  html{scroll-behavior:smooth}
  ::-webkit-scrollbar{width:4px}::-webkit-scrollbar-thumb{background:${G};border-radius:4px}
  input,textarea,select,button{font-family:'DM Sans',sans-serif}
  @keyframes floatA{0%,100%{transform:translateY(0)}50%{transform:translateY(-14px)}}
  @keyframes floatB{0%,100%{transform:translateY(0)}50%{transform:translateY(-9px)}}
  @keyframes floatC{0%,100%{transform:translateY(0)}33%{transform:translateY(-11px)}66%{transform:translateY(-3px)}}
  @keyframes twinkle{0%,100%{opacity:.9;transform:scale(1)}50%{opacity:.2;transform:scale(.6)}}
  @keyframes twinkleB{0%,100%{opacity:.4;transform:scale(.8)}50%{opacity:1;transform:scale(1.2)}}
  @keyframes fadeUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}
  @keyframes toast{from{opacity:0;transform:translate(-50%,10px)}to{opacity:1;transform:translate(-50%,0)}}
  .anim2{animation:fadeUp .5s .15s ease both;opacity:0;animation-fill-mode:both}
  .anim3{animation:fadeUp .5s .3s ease both;opacity:0;animation-fill-mode:both}
  .anim4{animation:fadeUp .5s .45s ease both;opacity:0;animation-fill-mode:both}
  .univers-icon{transition:transform .3s ease}
  .univers-card:hover .univers-icon{transform:scale(1.1) translateY(-4px)}
  .card-hover{transition:transform .25s ease,box-shadow .25s ease}
  .card-hover:hover{transform:translateY(-4px);box-shadow:0 20px 40px rgba(0,0,0,.12)!important}
  .btn-hover{transition:all .2s ease;cursor:pointer}
  .btn-hover:hover{opacity:.88;transform:translateY(-1px)}
  .nav-link:hover{color:${G}!important}
  .wish-btn{transition:transform .2s}
  .wish-btn:hover{transform:scale(1.15)}
`;

function injectCSS() {
  if (!document.getElementById("bdr-css")) {
    const s = document.createElement("style");
    s.id = "bdr-css";
    s.textContent = CSS;
    document.head.appendChild(s);
  }
}

/* ═══════════════════════════════════════════════════════════════════════════
   STORAGE (photos admin)
═══════════════════════════════════════════════════════════════════════════ */
async function loadPhotos(prods) {
  const r = {};
  for (const p of prods) {
    try {
      const x = await window.storage.get(`bdr-photos-${p.id}`, true);
      if (x?.value) { const a = JSON.parse(x.value); if (Array.isArray(a) && a.length) r[p.id] = a; }
    } catch {}
  }
  return r;
}

/* ═══════════════════════════════════════════════════════════════════════════
   RESPONSIVE HOOK
═══════════════════════════════════════════════════════════════════════════ */
function useBP() {
  const [w, setW] = useState(window.innerWidth);
  useEffect(() => {
    const h = () => setW(window.innerWidth);
    window.addEventListener("resize", h);
    return () => window.removeEventListener("resize", h);
  }, []);
  return { mob: w < 768, tab: w < 1024 };
}

/* ═══════════════════════════════════════════════════════════════════════════
   DATA
═══════════════════════════════════════════════════════════════════════════ */
const PRODUCTS = [
  {id:1, name:"Grand Boubou Brodé",      sub:"Boubou",        cat:"homme", artisan:"Moussa Diallo",   ville:"Dakar",      pays:"Sénégal",    flag:"🇸🇳",price:189,tag:"BEST",    tagColor:"#1A1714",stock:12,emoji:"◈"},
  {id:2, name:"Dashiki Festif",           sub:"Chemise",       cat:"homme", artisan:"Koffi Asante",    ville:"Accra",      pays:"Ghana",       flag:"🇬🇭",price:78, tag:"NOUVEAU", tagColor:"#1A1714",stock:25,emoji:"◈"},
  {id:3, name:"Agbada Cérémonie",         sub:"Tenue complète",cat:"homme", artisan:"Adebayo Okafor",  ville:"Lagos",      pays:"Nigeria",     flag:"🇳🇬",price:245,tag:"PREMIUM", tagColor:"#6A0040",stock:5, emoji:"◈"},
  {id:4, name:"Robe Wax Élégance",        sub:"Robe",          cat:"femme", artisan:"Fatoumata Koné",  ville:"Bamako",     pays:"Mali",        flag:"🇲🇱",price:134,tag:"BEST",    tagColor:"#1A1714",stock:18,emoji:"✦"},
  {id:5, name:"Ensemble Bogolan Chic",    sub:"Ensemble",      cat:"femme", artisan:"Awa Traoré",      ville:"Bamako",     pays:"Mali",        flag:"🇲🇱",price:168,tag:"NOUVEAU", tagColor:"#1A1714",stock:8, emoji:"✦"},
  {id:6, name:"Kaftan Soirée Brodé",      sub:"Kaftan",        cat:"femme", artisan:"Aïcha Diop",      ville:"Dakar",      pays:"Sénégal",    flag:"🇸🇳",price:212,tag:"PREMIUM", tagColor:"#6A0040",stock:6, emoji:"✦"},
  {id:7, name:"Mini Boubou Enfant",       sub:"Boubou",        cat:"enfant",artisan:"Moussa Diallo",   ville:"Dakar",      pays:"Sénégal",    flag:"🇸🇳",price:64, tag:"POPULAIRE",tagColor:"#1E5C2E",stock:30,emoji:"✧"},
  {id:8, name:"Robe Wax Princesse",       sub:"Robe",          cat:"enfant",artisan:"Koffi Mensah",    ville:"Lomé",       pays:"Togo",        flag:"🇹🇬",price:52, tag:"NOUVEAU", tagColor:"#1A1714",stock:20,emoji:"✧"},
  {id:9, name:"Ensemble Kente Junior",    sub:"Ensemble",      cat:"enfant",artisan:"Kweku Mensah",    ville:"Kumasi",     pays:"Ghana",       flag:"🇬🇭",price:88, tag:"ARTISANAL",tagColor:"#5A3A1A",stock:10,emoji:"✧"},
  {id:10,name:"Masque Ancestral Sénoufo", sub:"Sculpture",     cat:"art",   artisan:"Cheikh Ndiaye",   ville:"Thiès",      pays:"Sénégal",    flag:"🇸🇳",price:320,tag:"UNIQUE",   tagColor:"#3A1560",stock:3, emoji:"◆"},
  {id:11,name:"Sculpture Baobab Bronze",  sub:"Sculpture",     cat:"art",   artisan:"Cheikh Ndiaye",   ville:"Thiès",      pays:"Sénégal",    flag:"🇸🇳",price:445,tag:"PREMIUM",  tagColor:"#6A0040",stock:4, emoji:"◆"},
  {id:12,name:"Tableau Sahel Acrylique",  sub:"Peinture",      cat:"art",   artisan:"Amadou Sow",      ville:"Nouakchott", pays:"Mauritanie",  flag:"🇲🇷",price:278,tag:"ARTISANAL",tagColor:"#5A3A1A",stock:2, emoji:"◆"},
  {id:13,name:"Collier Perles Krobo",     sub:"Bijou",         cat:"divers",artisan:"Abena Asante",    ville:"Accra",      pays:"Ghana",       flag:"🇬🇭",price:86, tag:"ARTISANAL",tagColor:"#5A3A1A",stock:15,emoji:"❋"},
  {id:14,name:"Sac Bogolan Cuir",         sub:"Accessoire",    cat:"divers",artisan:"Fatoumata Koné",  ville:"Bamako",     pays:"Mali",        flag:"🇲🇱",price:112,tag:"ARTISANAL",tagColor:"#5A3A1A",stock:9, emoji:"❋"},
  {id:15,name:"Huile de Karité Pure",     sub:"Cosmétique",    cat:"divers",artisan:"Mariam Ouédraogo",ville:"Ouaga",      pays:"Burkina Faso",flag:"🇧🇫",price:34, tag:"BIO",      tagColor:"#1E5C2E",stock:50,emoji:"❋"},
  {id:16,name:"Tissu Wax 6 yards",        sub:"Tissu",         cat:"divers",artisan:"Koffi Mensah",    ville:"Lomé",       pays:"Togo",        flag:"🇹🇬",price:58, tag:"POPULAIRE",tagColor:"#1E5C2E",stock:35,emoji:"❋"},
];

const CATS = [
  {k:"tout",l:"Tout",e:"✦"},{k:"homme",l:"Homme",e:"◈"},{k:"femme",l:"Femme",e:"✦"},
  {k:"enfant",l:"Enfant",e:"✧"},{k:"art",l:"Art",e:"◆"},{k:"divers",l:"Divers",e:"❋"}
];

const ARTISANS = [
  {id:1,name:"Moussa Diallo",  metier:"Tailleur brodeur",         ville:"Dakar",  pays:"Sénégal", flag:"🇸🇳",exp:"23 ans",bio:"Formé par son père, il perpétue l'art ancestral du grand boubou. Chaque broderie est une histoire.",emoji:"◈"},
  {id:2,name:"Fatoumata Koné", metier:"Artisane bogolan",         ville:"Bamako", pays:"Mali",     flag:"🇲🇱",exp:"18 ans",bio:"Ressuscite les motifs anciens du bogolan, peint à la boue fermentée selon la tradition.",emoji:"✦"},
  {id:3,name:"Abena Asante",   metier:"Perlière Krobo",           ville:"Accra",  pays:"Ghana",    flag:"🇬🇭",exp:"15 ans",bio:"Dirige une coopérative de 12 femmes artisanes. Chaque perle est un symbole de transmission.",emoji:"❋"},
  {id:4,name:"Cheikh Ndiaye",  metier:"Sculpteur sur bois",       ville:"Thiès",  pays:"Sénégal", flag:"🇸🇳",exp:"30 ans",bio:"Maître sculpteur, gardien du bois de venn. Ses pièces voyagent dans le monde entier.",emoji:"◆"},
  {id:5,name:"Kweku Mensah",   metier:"Tisserand kente",          ville:"Kumasi", pays:"Ghana",    flag:"🇬🇭",exp:"25 ans",bio:"Tisserand royal de tradition Ashanti. Chaque bande de kente prend 3 jours à tisser.",emoji:"◈"},
  {id:6,name:"Aïcha Diop",     metier:"Couturière haute couture", ville:"Dakar",  pays:"Sénégal", flag:"🇸🇳",exp:"20 ans",bio:"Allie les codes de la couture africaine aux tendances contemporaines avec élégance.",emoji:"✦"},
];

/* ═══════════════════════════════════════════════════════════════════════════
   CONTEXT — uniquement les états partagés entre plusieurs composants
═══════════════════════════════════════════════════════════════════════════ */
const Ctx = createContext(null);
const useApp = () => useContext(Ctx);

/* ═══════════════════════════════════════════════════════════════════════════
   ATOMS
═══════════════════════════════════════════════════════════════════════════ */
function Toast({ msg, onClose }) {
  useEffect(() => { if (msg) { const t = setTimeout(onClose, 3000); return () => clearTimeout(t); } }, [msg, onClose]);
  if (!msg) return null;
  return (
    <div style={{position:"fixed",bottom:32,left:"50%",transform:"translateX(-50%)",background:DARK,color:"white",
      padding:"13px 26px",borderRadius:50,fontSize:13,fontFamily:SAN,zIndex:9999,
      boxShadow:"0 8px 32px rgba(0,0,0,.4)",animation:"toast .3s ease",whiteSpace:"nowrap",
      display:"flex",alignItems:"center",gap:10}}>
      <span style={{color:G}}>✦</span>{msg}
    </div>
  );
}

function Btn({ children, onClick, variant = "primary", sm, full, disabled, style: sx }) {
  const base = {
    primary: {background:DARK,color:"white",border:"none"},
    gold:    {background:G,color:DARK,border:"none"},
    ghost:   {background:"transparent",color:MUT,border:`1px solid ${BORD}`},
  }[variant] || {background:DARK,color:"white",border:"none"};
  return (
    <button disabled={disabled} onClick={onClick} className="btn-hover"
      style={{...base,borderRadius:50,padding:sm?"8px 20px":"12px 28px",fontSize:sm?12:14,
        fontWeight:600,fontFamily:SAN,cursor:disabled?"not-allowed":"pointer",
        letterSpacing:.5,width:full?"100%":undefined,opacity:disabled?.5:1,...sx}}>
      {children}
    </button>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   INPUT FIELD — composant réutilisable avec ref, JAMAIS de state global
═══════════════════════════════════════════════════════════════════════════ */
function Field({ label, fieldRef, type = "text", placeholder = "", defaultValue = "" }) {
  return (
    <div style={{marginBottom:14}}>
      <label style={{fontSize:10,fontWeight:700,color:MUT,textTransform:"uppercase",
        letterSpacing:1,display:"block",marginBottom:5,fontFamily:SAN}}>{label}</label>
      <input ref={fieldRef} type={type} defaultValue={defaultValue} placeholder={placeholder}
        style={{width:"100%",padding:"11px 16px",border:`1.5px solid ${BORD}`,borderRadius:10,
          fontSize:13,outline:"none",fontFamily:SAN,boxSizing:"border-box"}}/>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   PRODUCT CARD
═══════════════════════════════════════════════════════════════════════════ */
function PCard({ p, photos }) {
  const { addCart, wish, toggleWish } = useApp();
  const [idx, setIdx] = useState(0);
  const [added, setAdded] = useState(false);
  const arr = photos || [];

  const onAdd = e => {
    e.stopPropagation();
    addCart(p);
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  };

  return (
    <div className="card-hover" style={{background:"white",borderRadius:16,overflow:"hidden",
      boxShadow:"0 2px 12px rgba(0,0,0,.06)",cursor:"pointer"}}>
      <div style={{position:"relative",height:280,overflow:"hidden",background:BG2}}>
        {arr.length > 0
          ? <img src={arr[idx]} alt={p.name} style={{width:"100%",height:"100%",objectFit:"cover",display:"block"}}/>
          : <div style={{height:"100%",display:"flex",alignItems:"center",justifyContent:"center",
              background:`linear-gradient(135deg,${BG2},${BORD})`}}>
              <span style={{fontSize:80}}>{p.emoji}</span>
            </div>
        }
        {arr.length > 1 && <>
          <button onClick={e=>{e.stopPropagation();setIdx(i=>(i-1+arr.length)%arr.length);}}
            style={{position:"absolute",left:10,top:"50%",transform:"translateY(-50%)",
              background:"rgba(255,255,255,.85)",border:"none",width:28,height:28,borderRadius:"50%",
              display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",fontSize:14,color:DARK}}>‹</button>
          <button onClick={e=>{e.stopPropagation();setIdx(i=>(i+1)%arr.length);}}
            style={{position:"absolute",right:10,top:"50%",transform:"translateY(-50%)",
              background:"rgba(255,255,255,.85)",border:"none",width:28,height:28,borderRadius:"50%",
              display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",fontSize:14,color:DARK}}>›</button>
        </>}
        <div style={{position:"absolute",top:14,left:14,background:p.tagColor||DARK,color:"white",
          padding:"5px 12px",borderRadius:50,fontSize:11,fontWeight:700,fontFamily:SAN,letterSpacing:.8}}>{p.tag}</div>
        <div style={{position:"absolute",top:14,right:50,background:"rgba(255,255,255,.9)",
          padding:"5px 10px",borderRadius:50,fontSize:11,fontFamily:SAN,color:DARK,fontWeight:500}}>
          {p.flag} {p.pays}
        </div>
        <button onClick={e=>{e.stopPropagation();toggleWish(p.id);}} className="wish-btn"
          style={{position:"absolute",top:10,right:10,background:"rgba(255,255,255,.9)",border:"none",
            width:32,height:32,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",
            cursor:"pointer",fontSize:16}}>
          {wish.includes(p.id) ? "♥" : "♡"}
        </button>
        {p.stock < 5 && <div style={{position:"absolute",bottom:10,left:14,background:"rgba(255,255,255,.9)",
          color:RED,padding:"4px 10px",borderRadius:50,fontSize:10,fontWeight:700,fontFamily:SAN}}>
          Plus que {p.stock} !
        </div>}
      </div>
      <div style={{padding:"16px 18px 18px"}}>
        <div style={{fontSize:10,fontWeight:700,color:MUT,textTransform:"uppercase",letterSpacing:1.5,
          fontFamily:SAN,marginBottom:5}}>{p.sub}</div>
        <div style={{fontSize:17,fontWeight:700,color:TEXT,fontFamily:S,lineHeight:1.25,marginBottom:4}}>{p.name}</div>
        <div style={{fontSize:12,color:MUT,fontFamily:SAN,marginBottom:14}}>✦ {p.artisan}, {p.ville}</div>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div>
            <span style={{fontSize:22,fontWeight:700,color:TEXT,fontFamily:S}}>{p.price}</span>
            <span style={{fontSize:13,color:MUT,fontFamily:SAN}}> $CA</span>
          </div>
          <button onClick={onAdd} className="btn-hover"
            style={{background:added?GREEN:DARK,color:"white",border:"none",borderRadius:50,
              padding:"10px 18px",fontSize:13,fontWeight:600,fontFamily:SAN,cursor:"pointer",
              transition:"background .3s"}}>
            {added ? "✓ Ajouté" : "+ Panier"}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   HEADER — search 100% local, ne touche pas au context
═══════════════════════════════════════════════════════════════════════════ */
function Header() {
  const { page, go, user, cartCount, setCartOpen, menuOpen, setMenuOpen } = useApp();
  const { mob } = useBP();
  const [q, setQ] = useState("");   // LOCAL uniquement, jamais dans le context

  return (
    <header style={{background:DARK,position:"sticky",top:0,zIndex:200,boxShadow:"0 2px 20px rgba(0,0,0,.3)"}}>
      <div style={{maxWidth:1280,margin:"0 auto",padding:"0 24px",height:68,
        display:"flex",alignItems:"center",gap:mob?12:24}}>

        <div onClick={() => go("home")} style={{cursor:"pointer",flexShrink:0}}>
          <div style={{fontFamily:S,fontSize:mob?18:22,fontWeight:900,color:G,letterSpacing:3,lineHeight:1}}>BADAOUR</div>
          {!mob && <div style={{fontSize:8,color:`${G}70`,letterSpacing:3,textTransform:"uppercase",fontFamily:SAN}}>L'AFRIQUE À VOTRE PORTE</div>}
        </div>

        {!mob && (
          <div style={{flex:1,maxWidth:340,position:"relative"}}>
            <input
              value={q}
              onChange={e => setQ(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && q.trim()) { go("boutique"); } }}
              placeholder="Rechercher… (Entrée)"
              style={{width:"100%",padding:"10px 16px 10px 40px",background:"rgba(255,255,255,.08)",
                border:"1px solid rgba(255,255,255,.1)",borderRadius:50,color:"white",fontSize:13,
                outline:"none",fontFamily:SAN}}
            />
            <span style={{position:"absolute",left:14,top:"50%",transform:"translateY(-50%)",color:MUT,fontSize:16}}>⌕</span>
          </div>
        )}

        {!mob && (
          <nav style={{display:"flex",gap:4}}>
            {[["home","Accueil"],["boutique","Boutique"],["artisans","Artisans"],["suivi","Suivi"],["sur-mesure","Sur mesure"]].map(([k,l]) => (
              <button key={k} onClick={() => go(k)} className="nav-link"
                style={{background:page===k?`${G}18`:"transparent",color:page===k?G:"rgba(255,255,255,.7)",
                  border:page===k?`1px solid ${G}33`:"1px solid transparent",borderRadius:50,
                  padding:"8px 16px",fontSize:13,fontFamily:SAN,fontWeight:page===k?600:400,cursor:"pointer"}}>
                {l}
              </button>
            ))}
          </nav>
        )}

        <div style={{marginLeft:"auto",display:"flex",gap:8,alignItems:"center"}}>
          {!mob && (
            <button onClick={() => go("auth")} className="btn-hover"
              style={{background:"transparent",border:"1px solid rgba(255,255,255,.2)",color:"rgba(255,255,255,.8)",
                borderRadius:50,padding:"8px 16px",fontSize:13,fontFamily:SAN,cursor:"pointer",
                display:"flex",gap:6,alignItems:"center"}}>
              ◉ {user ? user.firstName : "Connexion"}
            </button>
          )}
          <button onClick={() => setCartOpen(true)} className="btn-hover"
            style={{background:G,border:"none",borderRadius:"50%",width:40,height:40,
              display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",
              position:"relative",fontSize:18}}>
            ⊡
            {cartCount > 0 && (
              <span style={{position:"absolute",top:-4,right:-4,background:RED,color:"white",
                borderRadius:"50%",width:18,height:18,display:"flex",alignItems:"center",
                justifyContent:"center",fontSize:10,fontWeight:700}}>
                {cartCount}
              </span>
            )}
          </button>
          {mob && (
            <button onClick={() => setMenuOpen(o => !o)}
              style={{background:"none",border:"none",color:"white",fontSize:22,cursor:"pointer"}}>≡</button>
          )}
        </div>
      </div>

      {mob && menuOpen && (
        <div style={{background:DARK,borderTop:"1px solid rgba(255,255,255,.1)",padding:16}}>
          {[["home","Accueil"],["boutique","Boutique"],["artisans","Artisans"],["suivi","Suivi"],["sur-mesure","Sur mesure"],["auth","Connexion"]].map(([k,l]) => (
            <button key={k} onClick={() => go(k)}
              style={{display:"block",width:"100%",textAlign:"left",padding:"12px 8px",background:"none",
                border:"none",color:page===k?G:"rgba(255,255,255,.7)",fontSize:15,fontFamily:SAN,
                cursor:"pointer",borderBottom:"1px solid rgba(255,255,255,.06)"}}>
              {l}
            </button>
          ))}
        </div>
      )}
    </header>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   CART DRAWER
═══════════════════════════════════════════════════════════════════════════ */
function CartDrawer() {
  const { cart, setCart, cartOpen, setCartOpen, cartCount, sub, ship, tax, tot, pPho, go, setStep } = useApp();
  const { mob } = useBP();
  if (!cartOpen) return null;

  return (
    <div style={{position:"fixed",inset:0,zIndex:500}} onClick={() => setCartOpen(false)}>
      <div onClick={e => e.stopPropagation()}
        style={{position:"fixed",top:0,right:0,bottom:0,width:mob?"100vw":420,background:"white",
          boxShadow:"-8px 0 40px rgba(0,0,0,.15)",display:"flex",flexDirection:"column"}}>
        <div style={{padding:"20px 24px",borderBottom:`1px solid ${BORD}`,display:"flex",
          justifyContent:"space-between",alignItems:"center"}}>
          <h2 style={{fontFamily:S,fontSize:20,color:TEXT}}>Panier ({cartCount})</h2>
          <button onClick={() => setCartOpen(false)} style={{background:"none",border:"none",fontSize:22,cursor:"pointer",color:MUT}}>×</button>
        </div>
        <div style={{flex:1,overflowY:"auto",padding:"16px 24px"}}>
          {!cart.length
            ? <div style={{textAlign:"center",padding:"60px 0",color:MUT,fontFamily:SAN}}>
                <div style={{fontSize:48,marginBottom:12}}>⊡</div>
                <div>Votre panier est vide</div>
              </div>
            : cart.map(it => (
              <div key={it.id} style={{display:"flex",gap:12,alignItems:"center",padding:"12px 0",borderBottom:`1px solid ${BORD}`}}>
                <div style={{width:60,height:60,borderRadius:10,background:BG2,display:"flex",
                  alignItems:"center",justifyContent:"center",overflow:"hidden",flexShrink:0}}>
                  {pPho[it.id]?.[0]
                    ? <img src={pPho[it.id][0]} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}}/>
                    : <span style={{fontSize:28}}>{it.emoji}</span>}
                </div>
                <div style={{flex:1}}>
                  <div style={{fontSize:14,fontWeight:600,color:TEXT,fontFamily:SAN}}>{it.name}</div>
                  <div style={{fontSize:12,color:MUT,fontFamily:SAN}}>{it.price} $CA</div>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:8}}>
                  <button onClick={() => setCart(c => c.map(x => x.id===it.id ? {...x,qty:Math.max(1,x.qty-1)} : x))}
                    style={{width:28,height:28,border:`1px solid ${BORD}`,borderRadius:"50%",background:"white",cursor:"pointer",fontSize:14}}>−</button>
                  <span style={{fontSize:14,fontWeight:600,fontFamily:SAN,minWidth:20,textAlign:"center"}}>{it.qty}</span>
                  <button onClick={() => setCart(c => c.map(x => x.id===it.id ? {...x,qty:x.qty+1} : x))}
                    style={{width:28,height:28,border:`1px solid ${BORD}`,borderRadius:"50%",background:"white",cursor:"pointer",fontSize:14}}>+</button>
                  <button onClick={() => setCart(c => c.filter(x => x.id !== it.id))}
                    style={{background:"none",border:"none",color:MUT,cursor:"pointer",fontSize:14,marginLeft:4}}>✕</button>
                </div>
              </div>
            ))
          }
        </div>
        {cart.length > 0 && (
          <div style={{padding:"16px 24px",borderTop:`1px solid ${BORD}`}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:4,fontSize:13,fontFamily:SAN,color:MUT}}>
              <span>Sous-total</span><span>{sub.toFixed(2)} $CA</span>
            </div>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:4,fontSize:13,fontFamily:SAN,color:MUT}}>
              <span>Livraison</span><span>{ship} $CA</span>
            </div>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:16,fontSize:15,fontFamily:SAN,
              fontWeight:700,color:TEXT,borderTop:`1px solid ${BORD}`,paddingTop:8}}>
              <span>Total (taxes incl.)</span><span>{tot} $CA</span>
            </div>
            <Btn variant="primary" full onClick={() => { setCartOpen(false); go("panier"); setStep("info"); }}>Commander →</Btn>
          </div>
        )}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   HERO CANVAS (particles)
═══════════════════════════════════════════════════════════════════════════ */
function HeroCanvas() {
  const ref = useRef(null);
  useEffect(() => {
    const c = ref.current; if (!c) return;
    const resize = () => { c.width = c.offsetWidth; c.height = c.offsetHeight; };
    resize();
    const pts = Array.from({length:90}, () => ({
      x:Math.random()*c.width, y:Math.random()*c.height,
      r:Math.random()*1.4+.4, a:Math.random()*.5+.1,
      da:(Math.random()-.5)*.008, vy:-(Math.random()*.15+.05),
      gold:Math.random()>.38
    }));
    let raf;
    const draw = () => {
      const ctx = c.getContext("2d");
      ctx.clearRect(0, 0, c.width, c.height);
      pts.forEach(p => {
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI*2);
        ctx.fillStyle = p.gold ? `rgba(201,168,76,${p.a})` : `rgba(255,255,255,${p.a*.45})`;
        ctx.fill();
        p.y += p.vy; p.a += p.da;
        if (p.y < 0) p.y = c.height;
        if (p.a < .05 || p.a > .75) p.da *= -1;
      });
      raf = requestAnimationFrame(draw);
    };
    draw();
    window.addEventListener("resize", resize);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, []);
  return <canvas ref={ref} style={{position:"absolute",inset:0,width:"100%",height:"100%",pointerEvents:"none",zIndex:1}}/>;
}

/* ═══════════════════════════════════════════════════════════════════════════
   HOME PAGE
═══════════════════════════════════════════════════════════════════════════ */
const FLOATERS = [{e:"✦",l:"62%",t:"10%",s:58,anim:"floatA",d:"0s"},{e:"◈",l:"80%",t:"22%",s:38,anim:"floatB",d:"1.2s"},{e:"✧",l:"76%",t:"46%",s:46,anim:"floatC",d:".6s"},{e:"◆",l:"60%",t:"62%",s:34,anim:"floatB",d:"1.8s"},{e:"✦",l:"72%",t:"74%",s:42,anim:"floatA",d:"2.4s"},{e:"◈",l:"84%",t:"65%",s:36,anim:"floatC",d:".9s"},{e:"✧",l:"88%",t:"36%",s:30,anim:"floatB",d:"1.5s"}];
const SPARKLES = [{l:"87%",t:"18%",big:true,d:"0s"},{l:"67%",t:"38%",big:false,d:"1.1s"},{l:"91%",t:"55%",big:false,d:".5s"},{l:"74%",t:"84%",big:false,d:"1.7s"},{l:"55%",t:"25%",big:false,d:".3s"}];

function Home() {
  const { go, setCat, pPho } = useApp();
  const { mob, tab } = useBP();
  return (
    <div>
      <section style={{background:`radial-gradient(ellipse 80% 60% at 70% 50%, rgba(80,55,10,.22) 0%, transparent 70%), ${HERO}`,
        minHeight:"92vh",display:"flex",flexDirection:"column",justifyContent:"center",
        position:"relative",overflow:"hidden",padding:mob?"48px 24px 120px":"0 80px 100px"}}>
        <HeroCanvas/>
        {!mob && FLOATERS.map((f,i) => (
          <div key={i} style={{position:"absolute",left:f.l,top:f.t,fontSize:f.s,
            animation:`${f.anim} ${3+i*.5}s ease-in-out infinite`,animationDelay:f.d,
            filter:"brightness(.42) sepia(.4) saturate(.7)",pointerEvents:"none",zIndex:2,userSelect:"none"}}>{f.e}</div>
        ))}
        {SPARKLES.map((sp,i) => (
          <div key={i} style={{position:"absolute",left:sp.l,top:sp.t,zIndex:2,pointerEvents:"none",
            animation:`${i%2===0?"twinkle":"twinkleB"} ${2.5+i*.4}s ease-in-out infinite`,animationDelay:sp.d,
            color:G,fontSize:sp.big?"22px":"14px",fontWeight:900,textShadow:`0 0 8px ${G}`}}>✦</div>
        ))}
        <div style={{position:"relative",zIndex:3,maxWidth:680,paddingTop:mob?0:40}}>
          <h1 className="anim2" style={{fontFamily:S,fontSize:mob?"42px":"76px",fontWeight:900,
            color:"rgba(255,255,255,.95)",lineHeight:1.02,marginBottom:22,letterSpacing:"-1px"}}>
            L'âme de l'Afrique,<br/><em style={{color:G,fontStyle:"italic"}}>livrée chez vous.</em>
          </h1>
          <div className="anim3" style={{width:56,height:2,background:G,marginBottom:28}}/>
          <p className="anim3" style={{fontSize:mob?14:16,color:"rgba(255,255,255,.55)",fontFamily:SAN,
            lineHeight:1.85,marginBottom:40,maxWidth:460,fontWeight:300}}>
            Habillement traditionnel, œuvres d'art et produits authentiques.<br/>
            De l'Afrique au Canada, créés par des artisans passionnés.
          </p>
          <div className="anim4" style={{display:"flex",gap:14,flexWrap:"wrap"}}>
            <button onClick={() => go("boutique")} className="btn-hover"
              style={{background:G,color:DARK,border:"none",borderRadius:50,padding:"15px 38px",
                fontSize:13,fontWeight:700,fontFamily:SAN,letterSpacing:2,cursor:"pointer",
                boxShadow:`0 8px 30px rgba(201,168,76,.35)`}}>EXPLORER LA BOUTIQUE</button>
            <button onClick={() => go("suivi")} className="btn-hover"
              style={{background:"transparent",color:"rgba(255,255,255,.8)",
                border:"1.5px solid rgba(255,255,255,.28)",borderRadius:50,padding:"15px 38px",
                fontSize:13,fontWeight:600,fontFamily:SAN,letterSpacing:2,cursor:"pointer"}}>SUIVRE UNE COMMANDE</button>
          </div>
        </div>
      </section>

      <section style={{background:BG,padding:mob?"52px 18px":"76px 80px"}}>
        <div style={{maxWidth:1280,margin:"0 auto"}}>
          <div style={{textAlign:"center",marginBottom:44}}>
            <div style={{fontSize:10,fontWeight:700,color:G,letterSpacing:5,textTransform:"uppercase",fontFamily:SAN,marginBottom:10}}>EXPLORER PAR UNIVERS</div>
            <h2 style={{fontFamily:S,fontSize:mob?30:44,color:TEXT,fontWeight:700}}>Nos 5 univers</h2>
          </div>
          <div style={{display:"grid",gridTemplateColumns:mob?"1fr 1fr":tab?"repeat(3,1fr)":"repeat(5,1fr)",gap:14}}>
            {[{k:"homme",e:"◈",border:"#1B2A5E",l:"Homme",desc:"Boubous, dashikis, agbadas"},
              {k:"femme",e:"✦",border:"#5E1B2A",l:"Femme",desc:"Robes wax, kaftans, ensembles"},
              {k:"enfant",e:"✧",border:"#1B5E2A",l:"Enfant",desc:"Tenues pour 2 à 14 ans"},
              {k:"art",e:"◆",border:"#3B1B5E",l:"Art",desc:"Sculptures, masques, tableaux"},
              {k:"divers",e:"❋",border:"#5E4A1B",l:"Divers",desc:"Bijoux, sacs, tissus, beauté"}
            ].map(u => (
              <div key={u.k} onClick={() => { setCat(u.k); go("boutique"); }}
                className="card-hover univers-card"
                style={{background:"white",borderRadius:14,padding:mob?"18px 14px":"28px 22px",
                  textAlign:"center",cursor:"pointer",border:`1.5px solid ${u.border}`}}>
                <div className="univers-icon" style={{fontSize:mob?36:52,marginBottom:14}}>{u.e}</div>
                <div style={{fontSize:mob?13:15,fontWeight:700,color:TEXT,fontFamily:SAN,marginBottom:6}}>{u.l}</div>
                <div style={{fontSize:11,color:MUT,fontFamily:SAN,lineHeight:1.55}}>{u.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section style={{background:BG2,padding:mob?"48px 18px":"68px 80px"}}>
        <div style={{maxWidth:1280,margin:"0 auto"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:36}}>
            <div>
              <div style={{fontSize:10,fontWeight:700,color:G,letterSpacing:5,textTransform:"uppercase",fontFamily:SAN,marginBottom:8}}>COUP DE CŒUR</div>
              <h2 style={{fontFamily:S,fontSize:mob?26:38,color:TEXT,fontWeight:700}}>Sélection de la semaine</h2>
            </div>
            <button onClick={() => go("boutique")} className="btn-hover"
              style={{background:"transparent",border:`1.5px solid ${BORD}`,borderRadius:50,
                padding:"11px 24px",fontSize:13,fontFamily:SAN,cursor:"pointer",color:TEXT,
                fontWeight:500,display:mob?"none":"flex",alignItems:"center",gap:6,whiteSpace:"nowrap"}}>Voir tout →</button>
          </div>
          <div style={{display:"grid",gridTemplateColumns:mob?"1fr 1fr":tab?"repeat(3,1fr)":"repeat(4,1fr)",gap:mob?12:20}}>
            {PRODUCTS.filter(p => ["BEST","POPULAIRE","NOUVEAU","PREMIUM"].includes(p.tag)).slice(0,4).map(p => (
              <PCard key={p.id} p={p} photos={pPho[p.id]}/>
            ))}
          </div>
        </div>
      </section>

      <section style={{background:DARK,padding:mob?"60px 24px":"88px 80px",textAlign:"center"}}>
        <div style={{maxWidth:720,margin:"0 auto"}}>
          <div style={{width:48,height:2,background:G,margin:"0 auto 36px"}}/>
          <h2 style={{fontFamily:S,fontSize:mob?26:42,color:"rgba(255,255,255,.92)",fontWeight:700,lineHeight:1.15,marginBottom:24}}>
            Né en Afrique,<br/>construit à <em style={{color:G,fontStyle:"italic"}}>Montréal.</em>
          </h2>
          <p style={{fontSize:mob?13:15,color:"rgba(255,255,255,.45)",fontFamily:SAN,lineHeight:1.9,maxWidth:580,margin:"0 auto 52px"}}>
            BADAOUR est né d'un désir profond : relier la diaspora africaine à ses racines. Chaque achat soutient directement un artisan, une famille, une communauté.
          </p>
          <div style={{display:"grid",gridTemplateColumns:mob?"1fr":"repeat(3,1fr)",gap:mob?28:0}}>
            {[["Commerce éthique","Rémunération juste"],["Impact direct","Soutien aux familles"],["Authenticité","Zéro intermédiaire"]].map(([t,d],i) => (
              <div key={t} style={{padding:mob?"0":"0 32px",borderLeft:(!mob&&i>0)?`1px solid rgba(255,255,255,.08)`:"none"}}>
                <div style={{width:36,height:2,background:G,margin:"0 auto 18px"}}/>
                <div style={{fontSize:15,fontWeight:700,color:"rgba(255,255,255,.85)",fontFamily:S,marginBottom:6}}>{t}</div>
                <div style={{fontSize:12,color:"rgba(255,255,255,.35)",fontFamily:SAN}}>{d}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   SHOP — search LOCAL au composant
═══════════════════════════════════════════════════════════════════════════ */
function Shop() {
  const { cat, setCat, pPho } = useApp();
  const { mob, tab } = useBP();
  const [search, setSearch] = useState("");   // LOCAL, jamais dans context

  const filtP = PRODUCTS.filter(p => {
    if (cat !== "tout" && p.cat !== cat) return false;
    if (search && !p.name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <div style={{background:BG,padding:mob?"24px 16px":"40px 80px",minHeight:"60vh"}}>
      <div style={{maxWidth:1280,margin:"0 auto"}}>
        <div style={{marginBottom:32}}>
          <div style={{fontSize:10,fontWeight:700,color:G,letterSpacing:4,textTransform:"uppercase",fontFamily:SAN,marginBottom:6}}>BADAOUR</div>
          <h1 style={{fontFamily:S,fontSize:mob?28:40,color:TEXT}}>Notre Boutique</h1>
        </div>

        <div style={{display:"flex",gap:8,marginBottom:24,flexWrap:"wrap",alignItems:"center"}}>
          <div style={{position:"relative",marginBottom:mob?8:0,width:mob?"100%":"auto"}}>
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Rechercher un produit..."
              style={{padding:"9px 16px 9px 36px",border:`1.5px solid ${BORD}`,borderRadius:50,
                fontSize:13,outline:"none",background:"white",fontFamily:SAN,
                width:mob?"100%":"220px",boxSizing:"border-box"}}
            />
            <span style={{position:"absolute",left:12,top:"50%",transform:"translateY(-50%)",color:MUT}}>⌕</span>
          </div>
          {CATS.map(c => (
            <button key={c.k} onClick={() => setCat(c.k)} className="btn-hover"
              style={{padding:"9px 20px",borderRadius:50,border:`1.5px solid ${cat===c.k?DARK:BORD}`,
                background:cat===c.k?DARK:"white",color:cat===c.k?"white":TEXT,
                fontSize:13,fontFamily:SAN,fontWeight:cat===c.k?700:400,cursor:"pointer",
                display:"flex",gap:6,alignItems:"center"}}>
              {c.e} {c.l}
            </button>
          ))}
        </div>

        <div style={{fontSize:12,color:MUT,fontFamily:SAN,marginBottom:20}}>{filtP.length} produit{filtP.length>1?"s":""}</div>
        <div style={{display:"grid",gridTemplateColumns:mob?"1fr 1fr":tab?"repeat(3,1fr)":"repeat(4,1fr)",gap:mob?12:20}}>
          {filtP.map(p => <PCard key={p.id} p={p} photos={pPho[p.id]}/>)}
        </div>
        {!filtP.length && (
          <div style={{textAlign:"center",padding:"80px 0",color:MUT,fontFamily:SAN}}>
            <div style={{fontSize:48,marginBottom:12}}>⌕</div>
            <div style={{fontSize:16}}>Aucun produit trouvé</div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   FORMULAIRE PARTENAIRE ARTISAN — dans l'onglet Artisans
═══════════════════════════════════════════════════════════════════════════ */
function PartenaireForm() {
  const { say } = useApp();
  const [sent, setSent] = useState(false);
  const r = { name:useRef(), metier:useRef(), pays:useRef(), email:useRef(), phone:useRef(), msg:useRef() };

  if (sent) return (
    <div style={{textAlign:"center",padding:"40px 0"}}>
      <div style={{fontSize:52,marginBottom:12}}>✦</div>
      <div style={{fontFamily:S,fontSize:22,color:TEXT,marginBottom:8}}>Demande envoyée !</div>
      <div style={{fontSize:13,color:MUT,fontFamily:SAN}}>Notre équipe vous répondra sous 48h.</div>
    </div>
  );

  const submit = () => {
    const g = k => r[k]?.current?.value || "";
    if (!g("name") || !g("email")) { say("Remplissez nom et email"); return; }
    const form = { name:g("name"), metier:g("metier"), pays:g("pays"), email:g("email"), phone:g("phone"), msg:g("msg") };
    setSent(true);
    sendArtisanConfirmation(form).then(res => say(res.success ? `✉ Confirmation envoyée à ${form.email}` : "Demande enregistrée ✓"));
  };

  return (
    <div>
      {[["Nom complet *","name","text"],["Métier / Spécialité","metier","text"],["Pays d'origine","pays","text"],["Email *","email","email"],["Téléphone / WhatsApp","phone","tel"]].map(([l,f,t]) => (
        <Field key={f} label={l} fieldRef={r[f]} type={t}/>
      ))}
      <div style={{marginBottom:16}}>
        <label style={{fontSize:10,fontWeight:700,color:MUT,textTransform:"uppercase",letterSpacing:1,display:"block",marginBottom:5,fontFamily:SAN}}>Votre message</label>
        <textarea ref={r.msg} defaultValue="" rows={4}
          style={{width:"100%",padding:"11px 16px",border:`1.5px solid ${BORD}`,borderRadius:10,
            fontSize:13,outline:"none",fontFamily:SAN,resize:"vertical",boxSizing:"border-box"}}/>
      </div>
      <button onClick={submit}
        style={{width:"100%",padding:"13px",background:G,color:DARK,border:"none",borderRadius:10,
          fontSize:13,fontWeight:700,fontFamily:SAN,cursor:"pointer"}}>
        Envoyer ma candidature →
      </button>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   ARTISANS PAGE — avec formulaire partenaire intégré en bas
═══════════════════════════════════════════════════════════════════════════ */
function ArtisansPage() {
  const { mob, tab } = useBP();
  return (
    <div style={{background:BG}}>
      <div style={{background:DARK,padding:mob?"48px 20px":"72px 80px",textAlign:"center"}}>
        <div style={{fontSize:10,fontWeight:700,color:G,letterSpacing:4,textTransform:"uppercase",fontFamily:SAN,marginBottom:8}}>RENCONTREZ</div>
        <h1 style={{fontFamily:S,fontSize:mob?32:52,color:"white",marginBottom:16}}>Nos artisans</h1>
        <p style={{color:"rgba(255,255,255,.5)",fontSize:14,fontFamily:SAN,maxWidth:500,margin:"0 auto"}}>
          Des créateurs passionnés qui perpétuent les traditions ancestrales africaines.
        </p>
      </div>

      <div style={{padding:mob?"32px 16px":"48px 80px",maxWidth:1280,margin:"0 auto"}}>
        <div style={{display:"grid",gridTemplateColumns:mob?"1fr":tab?"repeat(2,1fr)":"repeat(3,1fr)",gap:24}}>
          {ARTISANS.map(a => (
            <div key={a.id} className="card-hover" style={{background:"white",borderRadius:16,overflow:"hidden",
              border:`1px solid ${BORD}`,boxShadow:"0 2px 12px rgba(0,0,0,.05)"}}>
              <div style={{background:DARK,height:100,display:"flex",alignItems:"center",justifyContent:"center",fontSize:56}}>{a.emoji}</div>
              <div style={{padding:"20px"}}>
                <div style={{fontSize:10,color:MUT,textTransform:"uppercase",letterSpacing:2,fontWeight:700,fontFamily:SAN,marginBottom:4}}>{a.metier}</div>
                <div style={{fontSize:18,fontWeight:700,color:TEXT,fontFamily:S,marginBottom:2}}>{a.name}</div>
                <div style={{fontSize:12,color:MUT,fontFamily:SAN,marginBottom:12}}>{a.flag} {a.ville}, {a.pays} · ★ {a.exp} d'expérience</div>
                <p style={{fontSize:13,color:"#555",fontFamily:SAN,lineHeight:1.7,marginBottom:16}}>{a.bio}</p>
                <span style={{background:`${G}20`,color:DARK,padding:"4px 12px",borderRadius:50,fontSize:11,fontWeight:600,fontFamily:SAN,border:`1px solid ${G}44`}}>✓ Actif</span>
              </div>
            </div>
          ))}
        </div>

        {/* ── FORMULAIRE PARTENAIRE ── */}
        <div style={{marginTop:64}}>
          <div style={{textAlign:"center",marginBottom:40}}>
            <div style={{fontSize:10,fontWeight:700,color:G,letterSpacing:4,textTransform:"uppercase",fontFamily:SAN,marginBottom:8}}>REJOIGNEZ-NOUS</div>
            <h2 style={{fontFamily:S,fontSize:mob?26:38,color:TEXT,fontWeight:700}}>Devenir partenaire artisan</h2>
            <p style={{fontSize:14,color:MUT,fontFamily:SAN,marginTop:10,maxWidth:520,margin:"10px auto 0"}}>
              Vendez vos créations au Canada. Rémunération juste, paiement rapide, zéro intermédiaire.
            </p>
          </div>
          <div style={{display:"grid",gridTemplateColumns:mob?"1fr":"3fr 2fr",gap:40,maxWidth:1000,margin:"0 auto"}}>
            <div style={{background:"white",borderRadius:16,padding:mob?"24px":"40px",
              boxShadow:"0 4px 24px rgba(0,0,0,.07)",border:`1px solid ${BORD}`}}>
              <h3 style={{fontFamily:S,fontSize:mob?18:22,color:TEXT,marginBottom:6}}>Votre candidature</h3>
              <p style={{fontSize:13,color:MUT,fontFamily:SAN,marginBottom:24,lineHeight:1.6}}>
                Remplissez ce formulaire — notre équipe vous répondra sous 48h.
              </p>
              <PartenaireForm/>
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:14}}>
              {[["◈","50+ artisans actifs","Réseau de créateurs dans 10 pays africains."],
                ["✦","Rémunération juste","Vous fixez vos prix. Commission transparente."],
                ["◆","Paiement rapide","Virement sous 7 jours après chaque vente."],
                ["❋","Visibilité Canada","Des milliers de clients québécois et canadiens."],
                ["◉","Support complet",`${PHONE} · ${EMAIL}`]
              ].map(([e,t,d]) => (
                <div key={t} style={{background:"white",borderRadius:14,padding:"16px 20px",
                  border:`1px solid ${BORD}`,boxShadow:"0 2px 8px rgba(0,0,0,.04)",
                  display:"flex",gap:14,alignItems:"flex-start"}}>
                  <div style={{fontSize:22,flexShrink:0,color:G}}>{e}</div>
                  <div>
                    <div style={{fontSize:13,fontWeight:700,color:TEXT,fontFamily:S,marginBottom:3}}>{t}</div>
                    <div style={{fontSize:12,color:MUT,fontFamily:SAN,lineHeight:1.6}}>{d}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   SUIVI — tid/tres LOCAL au composant
═══════════════════════════════════════════════════════════════════════════ */
function Suivi() {
  const { orders, say } = useApp();
  const { mob } = useBP();
  const tidRef = useRef();
  const [tres, setTres] = useState(null);

  const search = () => {
    const val = tidRef.current?.value || "";
    const o = orders.find(x => x.id === val);
    if (o) setTres(o); else say("Commande introuvable");
  };

  return (
    <div style={{background:BG,minHeight:"60vh",padding:mob?"32px 16px":"64px 40px"}}>
      <div style={{maxWidth:560,margin:"0 auto"}}>
        <div style={{textAlign:"center",marginBottom:36}}>
          <div style={{fontSize:10,fontWeight:700,color:G,letterSpacing:4,textTransform:"uppercase",fontFamily:SAN,marginBottom:8}}>SUIVI</div>
          <h1 style={{fontFamily:S,fontSize:mob?28:38,color:TEXT}}>Suivre ma commande</h1>
        </div>
        <div style={{background:"white",borderRadius:16,padding:mob?"24px":"36px",
          boxShadow:"0 4px 20px rgba(0,0,0,.08)",border:`1px solid ${BORD}`}}>
          <label style={{fontSize:10,fontWeight:700,color:MUT,textTransform:"uppercase",letterSpacing:1,display:"block",marginBottom:6,fontFamily:SAN}}>
            Numéro de commande
          </label>
          <div style={{display:"flex",gap:10,marginBottom:20}}>
            <input ref={tidRef} defaultValue="" placeholder="BDR-2025-XXXX"
              style={{flex:1,padding:"12px 16px",border:`1.5px solid ${BORD}`,borderRadius:10,
                fontSize:14,outline:"none",fontFamily:SAN,boxSizing:"border-box"}}/>
            <Btn variant="primary" onClick={search}>Rechercher</Btn>
          </div>
          {tres && (
            <div style={{background:BG,borderRadius:12,padding:"20px"}}>
              <div style={{fontWeight:700,color:TEXT,fontFamily:S,fontSize:18,marginBottom:4}}>{tres.id}</div>
              <div style={{fontSize:12,color:MUT,fontFamily:SAN,marginBottom:16}}>{tres.date} · {tres.total?.toFixed(2)} $CA</div>
              <div style={{display:"flex",flexDirection:"column",gap:8}}>
                {["confirmed","preparation","shipped","transit","customs","delivery","delivered"].map((s,i) => {
                  const labels = {confirmed:"✓ Confirmée",preparation:"◈ En préparation",shipped:"⊡ Expédiée",transit:"→ En transit",customs:"◆ Dédouanement",delivery:"→ En livraison",delivered:"✦ Livrée !"};
                  const idx = ["confirmed","preparation","shipped","transit","customs","delivery","delivered"].indexOf(tres.status);
                  const done = i <= idx;
                  return (
                    <div key={s} style={{display:"flex",gap:12,alignItems:"center"}}>
                      <div style={{width:24,height:24,borderRadius:"50%",flexShrink:0,background:done?G:BORD,
                        display:"flex",alignItems:"center",justifyContent:"center",fontSize:12}}>{done?"✓":""}</div>
                      <span style={{fontSize:13,fontFamily:SAN,color:done?TEXT:MUT,fontWeight:done?600:400}}>{labels[s]}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
        {orders.length > 0 && (
          <div style={{marginTop:24}}>
            <div style={{fontSize:13,fontWeight:600,color:TEXT,fontFamily:SAN,marginBottom:12}}>Mes commandes récentes :</div>
            {orders.map(o => (
              <div key={o.id} onClick={() => setTres(o)}
                style={{background:"white",borderRadius:10,padding:"14px 18px",marginBottom:8,
                  cursor:"pointer",border:`1px solid ${BORD}`,display:"flex",justifyContent:"space-between"}}>
                <div>
                  <div style={{fontWeight:600,color:TEXT,fontFamily:SAN}}>{o.id}</div>
                  <div style={{fontSize:11,color:MUT,fontFamily:SAN}}>{o.date} · {o.total?.toFixed(2)} $CA</div>
                </div>
                <span style={{fontSize:11,color:G,fontFamily:SAN,fontWeight:600}}>{o.status}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   FORMULAIRE SUR MESURE — dans l'onglet Sur Mesure
═══════════════════════════════════════════════════════════════════════════ */
function SurMesureForm() {
  const { say } = useApp();
  const [sent, setSent] = useState(false);
  const r = { prenom:useRef(), nom:useRef(), email:useRef(), phone:useRef(), taille:useRef(), budget:useRef(), desc:useRef() };

  if (sent) return (
    <div style={{textAlign:"center",padding:"48px 0"}}>
      <div style={{fontSize:56,marginBottom:16}}>✦</div>
      <div style={{fontFamily:S,fontSize:22,color:TEXT,marginBottom:8}}>Demande reçue !</div>
      <div style={{fontSize:14,color:MUT,fontFamily:SAN,lineHeight:1.7}}>
        Notre équipe vous contactera sous 48h pour discuter de votre projet.
      </div>
    </div>
  );

  const submit = () => {
    const g = k => r[k]?.current?.value || "";
    if (!g("prenom") || !g("email") || !g("desc")) { say("Remplissez les champs obligatoires (*)"); return; }
    setSent(true);
    say("Demande sur mesure envoyée ✦");
  };

  return (
    <div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14,marginBottom:14}}>
        <div>
          <label style={{fontSize:10,fontWeight:700,color:MUT,textTransform:"uppercase",letterSpacing:1,display:"block",marginBottom:5,fontFamily:SAN}}>Prénom *</label>
          <input ref={r.prenom} type="text" defaultValue=""
            style={{width:"100%",padding:"11px 16px",border:`1.5px solid ${BORD}`,borderRadius:10,fontSize:13,outline:"none",fontFamily:SAN,boxSizing:"border-box"}}/>
        </div>
        <div>
          <label style={{fontSize:10,fontWeight:700,color:MUT,textTransform:"uppercase",letterSpacing:1,display:"block",marginBottom:5,fontFamily:SAN}}>Nom</label>
          <input ref={r.nom} type="text" defaultValue=""
            style={{width:"100%",padding:"11px 16px",border:`1.5px solid ${BORD}`,borderRadius:10,fontSize:13,outline:"none",fontFamily:SAN,boxSizing:"border-box"}}/>
        </div>
      </div>
      <Field label="Email *" fieldRef={r.email} type="email"/>
      <Field label="Téléphone / WhatsApp" fieldRef={r.phone} type="tel"/>
      <Field label="Taille / Mesures" fieldRef={r.taille} placeholder="Ex: 42, M, ou vos mesures en cm"/>
      <Field label="Budget estimé ($CA)" fieldRef={r.budget} placeholder="Ex: 150-300 $CA"/>
      <div style={{marginBottom:20}}>
        <label style={{fontSize:10,fontWeight:700,color:MUT,textTransform:"uppercase",letterSpacing:1,display:"block",marginBottom:5,fontFamily:SAN}}>Description de votre projet *</label>
        <textarea ref={r.desc} defaultValue="" rows={5}
          placeholder="Décrivez votre idée : type de vêtement, tissu souhaité, occasion, couleurs..."
          style={{width:"100%",padding:"11px 16px",border:`1.5px solid ${BORD}`,borderRadius:10,
            fontSize:13,outline:"none",fontFamily:SAN,resize:"vertical",boxSizing:"border-box",lineHeight:1.6}}/>
      </div>
      <button onClick={submit}
        style={{width:"100%",padding:"14px",background:G,color:DARK,border:"none",borderRadius:10,
          fontSize:14,fontWeight:700,fontFamily:SAN,cursor:"pointer"}}>
        Envoyer ma demande sur mesure →
      </button>
      <p style={{textAlign:"center",marginTop:12,fontSize:11,color:MUT,fontFamily:SAN}}>* Champs obligatoires · Réponse sous 48h</p>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   SUR MESURE PAGE — formulaire commande spéciale uniquement
═══════════════════════════════════════════════════════════════════════════ */
function SurMesure() {
  const { mob } = useBP();
  return (
    <div style={{background:BG}}>
      <div style={{background:DARK,padding:mob?"48px 20px":"72px 80px",textAlign:"center"}}>
        <div style={{fontSize:10,fontWeight:700,color:G,letterSpacing:4,textTransform:"uppercase",fontFamily:SAN,marginBottom:8}}>PERSONNALISÉ</div>
        <h1 style={{fontFamily:S,fontSize:mob?32:52,color:"white",marginBottom:16}}>Commande Sur Mesure</h1>
        <p style={{color:"rgba(255,255,255,.5)",fontFamily:SAN,fontSize:14,maxWidth:540,margin:"0 auto"}}>
          Une pièce unique à votre image, créée par nos artisans africains. Délai : 3 à 6 semaines.
        </p>
      </div>
      <div style={{padding:mob?"32px 16px":"48px 80px",maxWidth:1100,margin:"0 auto",
        display:"grid",gridTemplateColumns:mob?"1fr":"3fr 2fr",gap:40}}>
        <div style={{background:"white",borderRadius:16,padding:mob?"24px":"40px",
          boxShadow:"0 4px 24px rgba(0,0,0,.07)",border:`1px solid ${BORD}`}}>
          <h2 style={{fontFamily:S,fontSize:mob?20:26,color:TEXT,marginBottom:6}}>Décrivez votre projet</h2>
          <p style={{fontSize:13,color:MUT,fontFamily:SAN,marginBottom:28,lineHeight:1.6}}>
            Un artisan partenaire vous contactera pour discuter de votre commande personnalisée.
          </p>
          <SurMesureForm/>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:16}}>
          {[["◈","Pièce unique","Votre vêtement créé aux couleurs et dimensions que vous choisissez."],
            ["✦","Artisans certifiés","Réalisée par un artisan partenaire sélectionné avec soin."],
            ["◆","Délai 3–6 semaines","Production artisanale, expédition depuis l'Afrique vers le Canada."],
            ["❋","Commerce éthique","Prix justes, paiements rapides, impact direct."],
            ["◉","Support dédié",`${PHONE} · ${EMAIL}`]
          ].map(([e,t,d]) => (
            <div key={t} style={{background:"white",borderRadius:14,padding:"18px 22px",
              border:`1px solid ${BORD}`,boxShadow:"0 2px 8px rgba(0,0,0,.04)",
              display:"flex",gap:14,alignItems:"flex-start"}}>
              <div style={{fontSize:24,flexShrink:0,color:G}}>{e}</div>
              <div>
                <div style={{fontSize:14,fontWeight:700,color:TEXT,fontFamily:S,marginBottom:3}}>{t}</div>
                <div style={{fontSize:12,color:MUT,fontFamily:SAN,lineHeight:1.6}}>{d}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   AUTH FORM
═══════════════════════════════════════════════════════════════════════════ */
function AuthForm() {
  const { go, setUser, say } = useApp();
  const [mode, setMode] = useState("login");
  const [err, setErr] = useState("");
  const r = { prenom:useRef(), nom:useRef(), email:useRef(), pwd:useRef(), conf:useRef() };
  const g = k => r[k]?.current?.value || "";

  const submit = () => {
    if (mode === "login") {
      if (!g("email")) { setErr("Email obligatoire"); return; }
      setUser({ firstName:"Visiteur", lastName:"Test", email:g("email") });
      go("compte"); say("Connexion réussie ✦");
    } else {
      if (!g("prenom") || !g("email")) { setErr("Remplissez tous les champs"); return; }
      if (g("pwd") !== g("conf")) { setErr("Mots de passe différents"); return; }
      const nu = { firstName:g("prenom"), lastName:g("nom"), email:g("email") };
      setUser(nu); go("compte"); say(`Bienvenue ${nu.firstName} ✦`);
      setTimeout(() => sendWelcomeEmail(nu).then(res => say(res.success ? `✉ Email envoyé à ${nu.email}` : `⚠ ${res.error||"vérifiez Brevo"}`)), 800);
    }
  };

  return (
    <div style={{background:BG,minHeight:"70vh",display:"flex",alignItems:"center",justifyContent:"center",padding:20}}>
      <div style={{width:"100%",maxWidth:420}}>
        <div style={{textAlign:"center",marginBottom:28}}>
          <div style={{fontFamily:S,fontSize:24,color:TEXT,fontWeight:700}}>{mode==="login"?"Connexion":"Créer un compte"}</div>
        </div>
        <div style={{background:"white",borderRadius:16,padding:"40px",
          boxShadow:"0 8px 40px rgba(0,0,0,.08)",border:`1px solid ${BORD}`}}>
          <div style={{display:"flex",borderRadius:50,overflow:"hidden",border:`1.5px solid ${BORD}`,marginBottom:28}}>
            {[["login","Connexion"],["register","Inscription"]].map(([m,l]) => (
              <button key={m} onClick={() => { setMode(m); setErr(""); }}
                style={{flex:1,padding:11,border:"none",background:mode===m?DARK:"transparent",
                  color:mode===m?"white":MUT,cursor:"pointer",fontSize:13,fontWeight:700,fontFamily:SAN}}>
                {l}
              </button>
            ))}
          </div>
          {err && <p style={{color:"red",fontSize:12,marginBottom:12,fontFamily:SAN}}>{err}</p>}
          {mode === "register" && (
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:14}}>
              <div>
                <label style={{fontSize:10,color:MUT,fontWeight:700,letterSpacing:1,display:"block",marginBottom:4,fontFamily:SAN,textTransform:"uppercase"}}>Prénom *</label>
                <input ref={r.prenom} defaultValue="" style={{width:"100%",padding:"10px 14px",border:`1.5px solid ${BORD}`,borderRadius:10,fontSize:13,outline:"none",fontFamily:SAN,boxSizing:"border-box"}}/>
              </div>
              <div>
                <label style={{fontSize:10,color:MUT,fontWeight:700,letterSpacing:1,display:"block",marginBottom:4,fontFamily:SAN,textTransform:"uppercase"}}>Nom</label>
                <input ref={r.nom} defaultValue="" style={{width:"100%",padding:"10px 14px",border:`1.5px solid ${BORD}`,borderRadius:10,fontSize:13,outline:"none",fontFamily:SAN,boxSizing:"border-box"}}/>
              </div>
            </div>
          )}
          <div style={{marginBottom:14}}>
            <label style={{fontSize:10,color:MUT,fontWeight:700,letterSpacing:1,textTransform:"uppercase",display:"block",marginBottom:4,fontFamily:SAN}}>Email *</label>
            <input ref={r.email} type="email" defaultValue="" style={{width:"100%",padding:"11px 16px",border:`1.5px solid ${BORD}`,borderRadius:10,fontSize:13,outline:"none",fontFamily:SAN,boxSizing:"border-box"}}/>
          </div>
          <div style={{marginBottom:14}}>
            <label style={{fontSize:10,color:MUT,fontWeight:700,letterSpacing:1,textTransform:"uppercase",display:"block",marginBottom:4,fontFamily:SAN}}>Mot de passe</label>
            <input ref={r.pwd} type="password" defaultValue="" style={{width:"100%",padding:"11px 16px",border:`1.5px solid ${BORD}`,borderRadius:10,fontSize:13,outline:"none",fontFamily:SAN,boxSizing:"border-box"}}/>
          </div>
          {mode === "register" && (
            <div style={{marginBottom:14}}>
              <label style={{fontSize:10,color:MUT,fontWeight:700,letterSpacing:1,textTransform:"uppercase",display:"block",marginBottom:4,fontFamily:SAN}}>Confirmer</label>
              <input ref={r.conf} type="password" defaultValue="" style={{width:"100%",padding:"11px 16px",border:`1.5px solid ${BORD}`,borderRadius:10,fontSize:13,outline:"none",fontFamily:SAN,boxSizing:"border-box"}}/>
            </div>
          )}
          <button onClick={submit}
            style={{width:"100%",padding:"13px",background:G,color:DARK,border:"none",borderRadius:10,
              fontSize:13,fontWeight:700,fontFamily:SAN,cursor:"pointer",marginTop:8}}>
            {mode==="login"?"Se connecter":"Créer mon compte"}
          </button>
          <p style={{textAlign:"center",marginTop:14,fontSize:11,color:MUT,fontFamily:SAN}}>Démo : n'importe quel email</p>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   COMPTE
═══════════════════════════════════════════════════════════════════════════ */
function Compte() {
  const { user, setUser, orders, go } = useApp();
  const { mob } = useBP();

  if (!user) return (
    <div style={{padding:"60px",textAlign:"center"}}>
      <Btn variant="primary" onClick={() => go("auth")}>Se connecter</Btn>
    </div>
  );

  return (
    <div style={{background:BG,padding:mob?"24px 16px":"48px 80px",minHeight:"60vh"}}>
      <div style={{maxWidth:700,margin:"0 auto"}}>
        <div style={{background:"white",borderRadius:16,padding:"28px",boxShadow:"0 4px 20px rgba(0,0,0,.07)",border:`1px solid ${BORD}`,marginBottom:24}}>
          <div style={{display:"flex",gap:16,alignItems:"center",flexWrap:"wrap"}}>
            <div style={{width:56,height:56,borderRadius:"50%",background:DARK,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,fontWeight:700,color:G,fontFamily:S}}>
              {user.firstName[0]}
            </div>
            <div>
              <div style={{fontFamily:S,fontSize:20,fontWeight:700,color:TEXT}}>{user.firstName} {user.lastName}</div>
              <div style={{color:MUT,fontSize:13,fontFamily:SAN}}>{user.email}</div>
            </div>
            <button onClick={() => { setUser(null); go("home"); }}
              style={{marginLeft:"auto",background:"transparent",border:`1px solid ${BORD}`,
                color:MUT,padding:"8px 18px",borderRadius:50,cursor:"pointer",fontSize:12,fontFamily:SAN}}>
              Déconnexion
            </button>
          </div>
        </div>
        <h2 style={{fontFamily:S,fontSize:22,color:TEXT,marginBottom:16}}>Mes commandes</h2>
        {!orders.length
          ? <div style={{background:"white",borderRadius:16,padding:"48px",textAlign:"center",border:`1px solid ${BORD}`}}>
              <div style={{fontSize:40,marginBottom:12}}>◈</div>
              <div style={{color:MUT,fontFamily:SAN}}>Aucune commande pour l'instant.</div>
              <button onClick={() => go("boutique")} style={{marginTop:16,background:DARK,color:"white",border:"none",borderRadius:50,padding:"10px 24px",cursor:"pointer",fontFamily:SAN,fontWeight:600}}>Découvrir la boutique →</button>
            </div>
          : orders.map(o => (
            <div key={o.id} style={{background:"white",borderRadius:12,padding:"16px 20px",marginBottom:10,
              border:`1px solid ${BORD}`,display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:10}}>
              <div>
                <div style={{fontWeight:700,color:TEXT,fontFamily:SAN}}>{o.id}</div>
                <div style={{fontSize:12,color:MUT,fontFamily:SAN}}>{o.date} · {o.total?.toFixed(2)} $CA</div>
              </div>
              <div style={{display:"flex",gap:10,alignItems:"center"}}>
                <span style={{background:`${G}20`,color:DARK,padding:"4px 12px",borderRadius:50,fontSize:11,fontWeight:700,fontFamily:SAN}}>{o.status}</span>
                <button onClick={() => go("suivi")}
                  style={{background:"transparent",border:`1px solid ${BORD}`,color:MUT,padding:"6px 14px",borderRadius:50,cursor:"pointer",fontSize:11,fontFamily:SAN}}>
                  Suivre
                </button>
              </div>
            </div>
          ))
        }
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   LIVRAISON FORM — checkout step 1
═══════════════════════════════════════════════════════════════════════════ */
function LivraisonForm({ onContinue }) {
  const { say, setForm } = useApp();
  const { mob } = useBP();
  const r = { name:useRef(), email:useRef(), address:useRef(), city:useRef(), zip:useRef() };

  const submit = () => {
    const g = k => r[k]?.current?.value || "";
    if (!g("name") || !g("email")) { say("Nom et email obligatoires"); return; }
    setForm({ name:g("name"), email:g("email"), address:g("address"), city:g("city")||"Montréal", zip:g("zip") });
    onContinue();
  };

  return (
    <div style={{background:BG,padding:mob?"20px 16px":"48px 80px",minHeight:"70vh"}}>
      <div style={{maxWidth:600,margin:"0 auto"}}>
        <h2 style={{fontFamily:S,fontSize:mob?24:32,color:TEXT,marginBottom:28}}>◈ Informations de livraison</h2>
        <div style={{background:"white",borderRadius:16,padding:"32px",border:`1px solid ${BORD}`,boxShadow:"0 4px 20px rgba(0,0,0,.06)"}}>
          <Field label="Nom complet *" fieldRef={r.name}/>
          <Field label="Email *" fieldRef={r.email} type="email"/>
          <Field label="Adresse" fieldRef={r.address}/>
          <Field label="Ville" fieldRef={r.city} defaultValue="Montréal"/>
          <Field label="Code postal" fieldRef={r.zip}/>
          <button onClick={submit}
            style={{width:"100%",padding:"13px",background:G,color:DARK,border:"none",borderRadius:10,
              fontSize:13,fontWeight:700,fontFamily:SAN,cursor:"pointer",marginTop:8}}>
            Continuer vers le paiement →
          </button>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   PANIER / CHECKOUT
═══════════════════════════════════════════════════════════════════════════ */
function Panier() {
  const { cart, setCart, step, setStep, lastO, setLastO, setOrders, form, say, go, pPho, sub, ship, tax, tot, payM, setPayM, proc, setProc } = useApp();
  const { mob } = useBP();
  const cartCount = cart.reduce((a,x) => a+x.qty, 0);
  const genId = () => `BDR-${new Date().getFullYear()}-${Math.floor(1000+Math.random()*9000)}`;

  if (step === "confirmation" && lastO) return (
    <div style={{background:BG,minHeight:"70vh",display:"flex",alignItems:"center",justifyContent:"center",padding:20}}>
      <div style={{textAlign:"center",maxWidth:520}}>
        <div style={{fontSize:64,marginBottom:20}}>✦</div>
        <h1 style={{fontFamily:S,fontSize:mob?28:40,color:TEXT,marginBottom:12}}>Commande confirmée !</h1>
        <div style={{background:"white",borderRadius:14,padding:"20px 24px",border:`1px solid ${BORD}`,marginBottom:28,textAlign:"left"}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:6,fontSize:13,fontFamily:SAN}}>
            <span style={{color:MUT}}>Numéro</span><strong style={{color:TEXT}}>{lastO.id}</strong>
          </div>
          <div style={{display:"flex",justifyContent:"space-between",fontSize:13,fontFamily:SAN}}>
            <span style={{color:MUT}}>Total</span><strong style={{color:TEXT}}>{lastO.total?.toFixed(2)} $CA</strong>
          </div>
        </div>
        <div style={{display:"flex",gap:12,justifyContent:"center",flexWrap:"wrap"}}>
          <Btn variant="primary" onClick={() => { setStep("cart"); go("suivi"); }}>Suivre ma commande</Btn>
          <Btn variant="ghost" onClick={() => { setStep("cart"); go("boutique"); }}>Continuer mes achats</Btn>
        </div>
      </div>
    </div>
  );

  if (step === "info") return <LivraisonForm onContinue={() => setStep("payment")}/>;

  if (step === "payment") return (
    <div style={{background:BG,padding:mob?"20px 16px":"48px 80px",minHeight:"70vh"}}>
      <div style={{maxWidth:900,margin:"0 auto",display:"grid",gridTemplateColumns:mob?"1fr":"1fr 340px",gap:24}}>
        <div style={{background:"white",borderRadius:16,padding:mob?"24px":"32px",border:`1px solid ${BORD}`,boxShadow:"0 4px 20px rgba(0,0,0,.06)"}}>
          <h2 style={{fontFamily:S,fontSize:24,color:TEXT,marginBottom:22}}>◆ Paiement</h2>
          <div style={{display:"flex",gap:8,marginBottom:22,flexWrap:"wrap"}}>
            {[["card","▣ Carte"],["paypal","◉ PayPal"],["interac","◈ Interac"]].map(([v,l]) => (
              <button key={v} onClick={() => setPayM(v)}
                style={{flex:1,padding:"11px",border:`1.5px solid ${payM===v?DARK:BORD}`,borderRadius:10,
                  background:payM===v?DARK:"white",color:payM===v?"white":TEXT,cursor:"pointer",
                  fontSize:13,fontWeight:payM===v?700:400,fontFamily:SAN}}>{l}</button>
            ))}
          </div>
          {payM === "card" && [["Numéro de carte","**** **** **** 4567"],["Titulaire","NOM PRÉNOM"],["Expiration","MM/AA"],["CVV","•••"]].map(([l,ph]) => (
            <div key={l} style={{marginBottom:14}}>
              <label style={{fontSize:10,color:MUT,fontWeight:700,letterSpacing:1,textTransform:"uppercase",display:"block",marginBottom:5,fontFamily:SAN}}>{l}</label>
              <input placeholder={ph} style={{width:"100%",padding:"11px 16px",border:`1.5px solid ${BORD}`,borderRadius:10,fontSize:13,outline:"none",fontFamily:SAN,boxSizing:"border-box"}}/>
            </div>
          ))}
          {payM === "interac" && (
            <div style={{background:BG,border:`1px solid ${BORD}`,borderRadius:12,padding:18,fontSize:13,color:TEXT,fontFamily:SAN,lineHeight:1.8}}>
              Envoyez <strong>{tot} $CA</strong> à <strong style={{color:G}}>{EMAIL}</strong><br/>
              Question : <em>Nom boutique ?</em> · Réponse : <em style={{color:G}}>BADAOUR</em>
            </div>
          )}
          <Btn variant="primary" full disabled={proc} onClick={() => {
            setProc(true);
            setTimeout(() => {
              const o = { id:genId(), date:new Date().toLocaleDateString("fr-CA"), status:"confirmed",
                items:[...cart], total:parseFloat(tot), client:form.name||"Client", email:form.email, payMethod:payM };
              setOrders(p => [o,...p]); setLastO(o); setCart([]); setProc(false); setStep("confirmation");
              setTimeout(() => sendOrderConfirmation(o).then(r => say(r.success ? `✉ Confirmation envoyée à ${o.email}` : `Commande confirmée (email: ${r.error})`)), 600);
            }, 2000);
          }} style={{marginTop:18}}>
            {proc ? "⏳ Traitement..." : `⊠ Payer ${tot} $CA`}
          </Btn>
        </div>
        <div style={{background:"white",borderRadius:16,padding:24,border:`1px solid ${BORD}`,boxShadow:"0 4px 20px rgba(0,0,0,.06)",height:"fit-content"}}>
          <h3 style={{fontFamily:S,fontSize:18,color:TEXT,marginBottom:16}}>Résumé</h3>
          {cart.map(it => (
            <div key={it.id} style={{display:"flex",gap:10,marginBottom:12,alignItems:"center"}}>
              <div style={{width:44,height:44,background:BG2,borderRadius:8,flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,overflow:"hidden"}}>
                {pPho[it.id]?.[0] ? <img src={pPho[it.id][0]} alt="" style={{width:"100%",height:"100%",objectFit:"cover",borderRadius:8}}/> : it.emoji}
              </div>
              <div style={{flex:1,fontSize:12,fontFamily:SAN,color:TEXT}}>{it.name} ×{it.qty}</div>
              <div style={{fontSize:12,fontWeight:700,color:TEXT,fontFamily:SAN}}>{(it.price*it.qty).toFixed(2)} $</div>
            </div>
          ))}
          <div style={{borderTop:`1px solid ${BORD}`,paddingTop:12,marginTop:4}}>
            {[["Sous-total",sub.toFixed(2)+" $CA"],["Livraison",ship+" $CA"],["TPS/TVQ",tax+" $CA"],["Total",tot+" $CA"]].map(([l,v],i) => (
              <div key={l} style={{display:"flex",justifyContent:"space-between",marginBottom:6,
                fontSize:i===3?15:12,fontWeight:i===3?700:400,fontFamily:SAN,color:i===3?TEXT:MUT,
                paddingTop:i===3?8:0,borderTop:i===3?`1px solid ${BORD}`:0}}>
                <span>{l}</span><span>{v}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  // Cart view
  return (
    <div style={{background:BG,padding:mob?"24px 16px":"48px 80px",minHeight:"60vh"}}>
      <div style={{maxWidth:800,margin:"0 auto"}}>
        <h1 style={{fontFamily:S,fontSize:mob?28:36,color:TEXT,marginBottom:28}}>Votre panier ({cartCount})</h1>
        {!cart.length
          ? <div style={{background:"white",borderRadius:16,padding:"60px",textAlign:"center",border:`1px solid ${BORD}`}}>
              <div style={{fontSize:48,marginBottom:12}}>⊡</div>
              <div style={{color:MUT,fontFamily:SAN,marginBottom:20}}>Votre panier est vide</div>
              <Btn variant="primary" onClick={() => go("boutique")}>Découvrir la boutique</Btn>
            </div>
          : <div style={{display:"grid",gridTemplateColumns:mob?"1fr":"1fr 320px",gap:24,alignItems:"start"}}>
              <div style={{background:"white",borderRadius:16,padding:"24px",border:`1px solid ${BORD}`,boxShadow:"0 4px 20px rgba(0,0,0,.06)"}}>
                {cart.map(it => (
                  <div key={it.id} style={{display:"flex",gap:14,padding:"16px 0",borderBottom:`1px solid ${BORD}`}}>
                    <div style={{width:72,height:72,borderRadius:10,background:BG2,overflow:"hidden",flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center"}}>
                      {pPho[it.id]?.[0] ? <img src={pPho[it.id][0]} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}}/> : <span style={{fontSize:36}}>{it.emoji}</span>}
                    </div>
                    <div style={{flex:1}}>
                      <div style={{fontSize:15,fontWeight:700,color:TEXT,fontFamily:S,marginBottom:2}}>{it.name}</div>
                      <div style={{fontSize:12,color:MUT,fontFamily:SAN,marginBottom:10}}>✦ {it.artisan}</div>
                      <div style={{display:"flex",gap:8,alignItems:"center"}}>
                        <button onClick={() => setCart(c => c.map(x => x.id===it.id ? {...x,qty:Math.max(1,x.qty-1)} : x))} style={{width:28,height:28,border:`1px solid ${BORD}`,borderRadius:"50%",background:"white",cursor:"pointer",fontSize:14}}>−</button>
                        <span style={{fontSize:14,fontWeight:600,fontFamily:SAN,minWidth:24,textAlign:"center"}}>{it.qty}</span>
                        <button onClick={() => setCart(c => c.map(x => x.id===it.id ? {...x,qty:x.qty+1} : x))} style={{width:28,height:28,border:`1px solid ${BORD}`,borderRadius:"50%",background:"white",cursor:"pointer",fontSize:14}}>+</button>
                        <button onClick={() => setCart(c => c.filter(x => x.id !== it.id))} style={{background:"none",border:"none",color:MUT,cursor:"pointer",fontSize:12,fontFamily:SAN,marginLeft:8}}>Supprimer</button>
                      </div>
                    </div>
                    <div style={{fontWeight:700,fontSize:16,color:TEXT,fontFamily:S}}>{(it.price*it.qty).toFixed(2)} $</div>
                  </div>
                ))}
              </div>
              <div style={{background:"white",borderRadius:16,padding:"24px",border:`1px solid ${BORD}`,boxShadow:"0 4px 20px rgba(0,0,0,.06)"}}>
                <h3 style={{fontFamily:S,fontSize:18,color:TEXT,marginBottom:16}}>Résumé de commande</h3>
                {[["Sous-total",sub.toFixed(2)+" $CA"],["Livraison","18 $CA"],["TPS/TVQ",tax+" $CA"]].map(([l,v]) => (
                  <div key={l} style={{display:"flex",justifyContent:"space-between",marginBottom:8,fontSize:13,fontFamily:SAN,color:MUT}}><span>{l}</span><span>{v}</span></div>
                ))}
                <div style={{display:"flex",justifyContent:"space-between",fontSize:15,fontWeight:700,fontFamily:SAN,color:TEXT,borderTop:`1px solid ${BORD}`,paddingTop:10,marginTop:4,marginBottom:16}}>
                  <span>Total</span><span>{tot} $CA</span>
                </div>
                <Btn variant="primary" full onClick={() => setStep("info")}>Commander →</Btn>
                <p style={{textAlign:"center",marginTop:10,fontSize:11,color:MUT,fontFamily:SAN}}>⊠ Paiement 100% sécurisé</p>
              </div>
            </div>
        }
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   FOOTER
═══════════════════════════════════════════════════════════════════════════ */
function Footer() {
  const { go } = useApp();
  const { mob } = useBP();
  return (
    <footer style={{background:DARK,padding:mob?"40px 20px 24px":"60px 80px 32px"}}>
      <div style={{maxWidth:1280,margin:"0 auto"}}>
        <div style={{display:"grid",gridTemplateColumns:mob?"1fr 1fr":"240px repeat(3,1fr)",gap:mob?24:40,marginBottom:40}}>
          <div>
            <div style={{fontFamily:S,fontSize:22,fontWeight:900,color:G,letterSpacing:3,marginBottom:8}}>BADAOUR</div>
            <p style={{fontSize:13,color:"rgba(255,255,255,.4)",fontFamily:SAN,lineHeight:1.7,marginBottom:16}}>L'Afrique à votre porte. Commerce éthique, artisanat authentique, livraison partout au Canada.</p>
            <div style={{fontSize:12,color:"rgba(255,255,255,.4)",fontFamily:SAN}}>✆ {PHONE}</div>
            <div style={{fontSize:12,color:"rgba(255,255,255,.4)",fontFamily:SAN,marginTop:4}}>✉ {EMAIL}</div>
          </div>
          {[{title:"BOUTIQUE",links:[["homme","Homme"],["femme","Femme"],["enfant","Enfant"],["art","Art"],["divers","Accessoires"]]},
            {title:"BADAOUR",links:[["home","Notre histoire"],["artisans","Nos artisans"],["artisans","Partenaire"]]},
            {title:"AIDE",links:[["suivi","Livraison"],["sur-mesure","Sur mesure"],["compte","Mon compte"]]}
          ].map(col => (
            <div key={col.title}>
              <div style={{fontSize:10,fontWeight:700,color:G,letterSpacing:3,textTransform:"uppercase",fontFamily:SAN,marginBottom:16}}>{col.title}</div>
              {col.links.map(([k,l]) => (
                <div key={l} onClick={() => go(k)} className="nav-link"
                  style={{fontSize:13,color:"rgba(255,255,255,.45)",fontFamily:SAN,marginBottom:8,cursor:"pointer"}}>{l}</div>
              ))}
            </div>
          ))}
        </div>
        <div style={{borderTop:"1px solid rgba(255,255,255,.08)",paddingTop:20}}>
          <div style={{fontSize:11,color:"rgba(255,255,255,.25)",fontFamily:SAN}}>© 2026 BADAOUR · Montréal, Québec · Canada</div>
        </div>
      </div>
    </footer>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   ROUTER
═══════════════════════════════════════════════════════════════════════════ */
function PageContent() {
  const { page } = useApp();
  if (page === "home")       return <Home/>;
  if (page === "boutique")   return <Shop/>;
  if (page === "artisans")   return <ArtisansPage/>;
  if (page === "suivi")      return <Suivi/>;
  if (page === "sur-mesure") return <SurMesure/>;
  if (page === "auth")       return <AuthForm/>;
  if (page === "compte")     return <Compte/>;
  if (page === "panier")     return <Panier/>;
  return <Home/>;
}

/* ═══════════════════════════════════════════════════════════════════════════
   APP ROOT — context provider + state global uniquement
═══════════════════════════════════════════════════════════════════════════ */
export default function Boutique() {
  useEffect(() => { injectCSS(); }, []);

  const [page,     setPage]     = useState("home");
  const [cat,      setCat]      = useState("tout");
  const [wish,     setWish]     = useState([]);
  const [cart,     setCart]     = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [toast,    setToast]    = useState("");
  const [pPho,     setPPho]     = useState({});
  const [user,     setUser]     = useState(null);
  const [form,     setForm]     = useState({ name:"", email:"", address:"", city:"Montréal", zip:"" });
  const [step,     setStep]     = useState("cart");
  const [payM,     setPayM]     = useState("card");
  const [proc,     setProc]     = useState(false);
  const [lastO,    setLastO]    = useState(null);
  const [orders,   setOrders]   = useState([]);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => { loadPhotos(PRODUCTS).then(pm => { if (Object.keys(pm).length) setPPho(pm); }); }, []);

  const say       = useCallback(m => setToast(m), []);
  const go        = useCallback(p => { setPage(p); setMenuOpen(false); window.scrollTo({ top:0, behavior:"smooth" }); }, []);
  const addCart   = useCallback(p => {
    setCart(c => { const ex = c.find(x => x.id===p.id); return ex ? c.map(x => x.id===p.id ? {...x,qty:x.qty+1} : x) : [...c,{...p,qty:1}]; });
    setToast(`${p.name} ajouté au panier ✓`);
  }, []);
  const toggleWish = useCallback(id => {
    setWish(w => {
      const has = w.includes(id);
      const p = PRODUCTS.find(x => x.id===id);
      setToast(has ? "Retiré des favoris" : `${p?.name} ajouté aux favoris ♥`);
      return has ? w.filter(x => x!==id) : [...w, id];
    });
  }, []);

  const sub  = cart.reduce((a,x) => a+x.price*x.qty, 0);
  const ship = sub > 0 ? 18 : 0;
  const tax  = ((sub+ship)*0.15).toFixed(2);
  const tot  = (sub+ship+parseFloat(tax)).toFixed(2);
  const cartCount = cart.reduce((a,x) => a+x.qty, 0);

  const ctx = {
    page, go, cat, setCat, wish, toggleWish,
    cart, setCart, cartOpen, setCartOpen, cartCount,
    pPho, user, setUser, form, setForm,
    step, setStep, payM, setPayM, proc, setProc,
    lastO, setLastO, orders, setOrders,
    menuOpen, setMenuOpen, say, addCart,
    sub, ship, tax, tot,
  };

  return (
    <Ctx.Provider value={ctx}>
      <div style={{minHeight:"100vh",background:BG,color:TEXT,fontFamily:SAN}}>
        <Header/>
        <main><PageContent/></main>
        <Footer/>
        <CartDrawer/>
        <Toast msg={toast} onClose={() => setToast("")}/>
        <button onClick={() => openWhatsApp("14389886682", user ? `Bonjour BADAOUR ! Je suis ${user.firstName} et j'ai besoin d'aide.` : "Bonjour BADAOUR ! J'ai besoin d'aide.")}
          style={{position:"fixed",bottom:24,right:24,background:"#25D366",borderRadius:"50%",
            width:52,height:52,display:"flex",alignItems:"center",justifyContent:"center",
            fontSize:22,border:"none",boxShadow:"0 6px 20px rgba(37,211,102,.4)",
            zIndex:99,cursor:"pointer",color:"white",fontWeight:900}}>
          ✆
        </button>
      </div>
    </Ctx.Provider>
  );
}
