/**
 * BADAOUR — Module de communication centralisé
 * Gère tous les envois : email, WhatsApp, notifications
 */

const API_URL = "/api/send-email";

/**
 * Envoie un email via l'API Vercel → Brevo
 * @param {string} type - commande | bienvenue | suivi | artisan | custom
 * @param {string} to - email destinataire
 * @param {string} toName - nom destinataire
 * @param {object} data - données du template
 */
export async function sendEmail(type, to, toName, data = {}) {
  try {
    const res = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type, to, toName, data }),
    });
    const result = await res.json();
    if (!res.ok) throw new Error(result.error || "Erreur envoi");
    return { success: true, messageId: result.messageId };
  } catch (err) {
    console.error("sendEmail error:", err);
    return { success: false, error: err.message };
  }
}

/**
 * Email de confirmation de commande
 */
export async function sendOrderConfirmation(order) {
  return sendEmail(
    "commande",
    order.email,
    order.client,
    {
      client: order.client,
      orderId: order.id,
      items: order.items,
      total: order.total?.toFixed(2),
    }
  );
}

/**
 * Email de bienvenue lors de l'inscription
 */
export async function sendWelcomeEmail(user) {
  return sendEmail(
    "bienvenue",
    user.email,
    `${user.firstName} ${user.lastName}`,
    {
      client: `${user.firstName} ${user.lastName}`,
    }
  );
}

/**
 * Email de mise à jour de suivi
 */
export async function sendTrackingUpdate(order, newStatus, message = "") {
  return sendEmail(
    "suivi",
    order.email,
    order.client,
    {
      client: order.client,
      orderId: order.id,
      newStatus,
      message,
    }
  );
}

/**
 * Email de confirmation de demande artisan partenaire
 */
export async function sendArtisanConfirmation(form) {
  return sendEmail(
    "artisan",
    form.email,
    form.name,
    {
      name: form.name,
      metier: form.metier,
      pays: form.pays,
      phone: form.phone,
    }
  );
}

/**
 * Email personnalisé (depuis admin)
 */
export async function sendCustomEmail(to, toName, subject, message) {
  return sendEmail("custom", to, toName, { subject, message, client: toName });
}

/**
 * Ouvre WhatsApp avec un message pré-rempli
 */
export function openWhatsApp(phone = "14389886682", message = "") {
  const encoded = encodeURIComponent(message);
  window.open(`https://wa.me/${phone}?text=${encoded}`, "_blank");
}

/**
 * Message WhatsApp pour confirmation de commande
 */
export function whatsAppOrder(order) {
  const msg = `Bonjour BADAOUR ! 🌍\n\nJe viens de passer la commande *${order.id}* d'un montant de *${order.total?.toFixed(2)} $CA*.\n\nMerci !`;
  openWhatsApp("14389886682", msg);
}

/**
 * Message WhatsApp pour support client
 */
export function whatsAppSupport(clientName = "") {
  const msg = `Bonjour BADAOUR,\n\nJe m'appelle ${clientName} et j'ai besoin d'aide.\n\nMerci !`;
  openWhatsApp("14389886682", msg);
}
